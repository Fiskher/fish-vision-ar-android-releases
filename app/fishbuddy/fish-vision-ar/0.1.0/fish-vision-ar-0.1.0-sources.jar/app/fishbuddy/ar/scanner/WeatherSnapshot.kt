package app.fishbuddy.ar.scanner

/**
 * Weather at the scan time and place, as observed by the consumer.
 *
 * @param airTemperatureCelsius outdoor air temperature.
 * @param windSpeedMetersPerSecond wind speed.
 * @param conditionTag short tag (`"clear"`, `"overcast"`, `"rain"`, …) — vocabulary
 *   intentionally loose for v1; the backend treats it as a string label.
 */
public data class WeatherSnapshot(
    public val airTemperatureCelsius: Double? = null,
    public val windSpeedMetersPerSecond: Double? = null,
    public val conditionTag: String? = null,
)
