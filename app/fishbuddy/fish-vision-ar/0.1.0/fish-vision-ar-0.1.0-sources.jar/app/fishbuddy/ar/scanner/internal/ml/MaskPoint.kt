package app.fishbuddy.ar.scanner.internal.ml

/**
 * (x, y) tuple used by the segmentation → depth pipeline. Modeled as a plain Kotlin
 * value class so the pipeline stays unit-testable on the JVM — `android.graphics.Point`
 * is part of the AGP mock `android.jar` and its fields return `0` outside Robolectric,
 * which previously made the endpoint-detector tests false-pass.
 */
internal data class MaskPoint(val x: Int, val y: Int)
