package app.fishbuddy.ar.scanner.internal.ar.common.rendering

import android.content.Context
import android.opengl.GLES20
import android.opengl.Matrix
import com.google.ar.core.Camera
import app.fishbuddy.ar.scanner.internal.ar.rawdepth.DepthConstants
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer


/**
 * A two-dimensional square for use as a drawn object in OpenGL ES 2.0.
 */
internal class SquareRenderer {

//    private val vertexShaderCode =  // This matrix member variable provides a hook to manipulate
//        // the coordinates of the objects that use this vertex shader
//        "uniform mat4 uMVPMatrix;" +
//                "attribute vec4 vPosition;" +
//                "void main() {" +  // The matrix must be included as a modifier of gl_Position.
//                // Note that the uMVPMatrix factor *must be first* in order
//                // for the matrix multiplication product to be correct.
//                "  gl_Position = uMVPMatrix * vPosition;" +
//                "}"
//    private val fragmentShaderCode = ("precision mediump float;" +
//            "uniform vec4 vColor;" +
//            "void main() {" +
//            "  gl_FragColor = vColor;" +
//            "}")

    private val VERTEX_SHADER_NAME = "shaders/bbox.vert"
    private val FRAGMENT_SHADER_NAME = "shaders/bbox.frag"

    val BYTES_PER_FLOAT = java.lang.Float.SIZE / 8
    private val BYTES_PER_POINT = BYTES_PER_FLOAT * DepthConstants.FLOATS_PER_POINT
    private val INITIAL_BUFFER_POINTS = 1000

    private var arrayBuffer = 0
    private var arrayBufferSize = 0

    private var programName = 0
    private var positionAttribute = 0
    private var modelViewProjectionUniform = 0
    private var pointSizeUniform = 0

    private var vertexBuffer: FloatBuffer? = null
    private var drawListBuffer: ShortBuffer? = null
    private var mProgram: Int = 0
    private var mPositionHandle = 0
    private var mColorHandle = 0
    private var mMVPMatrixHandle = 0
    private val drawOrder = shortArrayOf(0, 1, 2, 0, 2, 3) // order to draw vertices
    private val vertexStride = COORDS_PER_VERTEX * 4 // 4 bytes per vertex
    var color = floatArrayOf(0.2f, 0.709803922f, 0.898039216f, 1.0f)

    @Throws(IOException::class)
    fun createOnGlThread(context: Context?) {
        ShaderUtil.checkGLError(TAG, "Bind")

//        val buffers = IntArray(1)
//        GLES20.glGenBuffers(1, buffers, 0)
//        arrayBuffer = buffers[0]
//        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, arrayBuffer)
//
//        arrayBufferSize = INITIAL_BUFFER_POINTS * BYTES_PER_POINT
//        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, arrayBufferSize, null, GLES20.GL_DYNAMIC_DRAW)
//        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
//
//        ShaderUtil.checkGLError(TAG, "Create")
//
//        val vertexShader = ShaderUtil.loadGLShader(
//            TAG,
//            context,
//            GLES20.GL_VERTEX_SHADER,
//            VERTEX_SHADER_NAME
//        )
//        val fragmentShader = ShaderUtil.loadGLShader(
//            TAG,
//            context,
//            GLES20.GL_FRAGMENT_SHADER,
//            FRAGMENT_SHADER_NAME
//        )
//
//        programName = GLES20.glCreateProgram()
//        GLES20.glAttachShader(programName, vertexShader)
//        GLES20.glAttachShader(programName, fragmentShader)
//        GLES20.glLinkProgram(programName)
//        GLES20.glUseProgram(programName)
//
//        ShaderUtil.checkGLError(TAG, "Program")
//
//        positionAttribute = GLES20.glGetAttribLocation(programName, "v_Position")
//        modelViewProjectionUniform =
//            GLES20.glGetUniformLocation(programName, "u_ModelViewProjection")
//        pointSizeUniform = GLES20.glGetUniformLocation(programName, "u_PointSize")
//
//        ShaderUtil.checkGLError(TAG, "Init complete")

        // initialize vertex byte buffer for shape coordinates
        val bb: ByteBuffer = ByteBuffer.allocateDirect( // (# of coordinate values * 4 bytes per float)
            squareCoords.size * 4)
        bb.order(ByteOrder.nativeOrder())
        vertexBuffer = bb.asFloatBuffer()
        vertexBuffer!!.put(squareCoords)
        vertexBuffer!!.position(0)
        // initialize byte buffer for the draw list
        val dlb: ByteBuffer = ByteBuffer.allocateDirect( // (# of coordinate values * 2 bytes per short)
            drawOrder.size * 2)
        dlb.order(ByteOrder.nativeOrder())
        drawListBuffer = dlb.asShortBuffer()
        drawListBuffer!!.put(drawOrder)
        drawListBuffer!!.position(0)

        // prepare shaders and OpenGL program
        ShaderUtil.checkGLError(TAG, "Create")
        val vertexShader = ShaderUtil.loadGLShader(
            TAG,
            context,
            GLES20.GL_VERTEX_SHADER,
            VERTEX_SHADER_NAME
        )
        val fragmentShader = ShaderUtil.loadGLShader(
            TAG,
            context,
            GLES20.GL_FRAGMENT_SHADER,
            FRAGMENT_SHADER_NAME
        )

        mProgram = GLES20.glCreateProgram() // create empty OpenGL Program
        GLES20.glAttachShader(mProgram, vertexShader) // add the vertex shader to program
        GLES20.glAttachShader(mProgram, fragmentShader) // add the fragment shader to program
        GLES20.glLinkProgram(mProgram) // create OpenGL program executables

        ShaderUtil.checkGLError(TAG, "Program")
        // get handle to vertex shader's vPosition member
        mPositionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition")
        // get handle to fragment shader's vColor member
        mColorHandle = GLES20.glGetUniformLocation(mProgram, "vColor")
        // get handle to shape's transformation matrix
        mMVPMatrixHandle = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix")
//                positionAttribute = GLES20.glGetAttribLocation(programName, "a_Position")
//        modelViewProjectionUniform =
//            GLES20.glGetUniformLocation(programName, "u_ModelViewProjection")
//        pointSizeUniform = GLES20.glGetUniformLocation(programName, "u_PointSize")
        ShaderUtil.checkGLError(TAG, "Init complete")
    }

    /**
     * Encapsulates the OpenGL ES instructions for drawing this shape.
     *
     * @param mvpMatrix - The Model View Project matrix in which to draw
     * this shape.
     */
    fun draw(camera: Camera) {
        val projectionMatrix = FloatArray(16)
        camera.getProjectionMatrix(projectionMatrix, 0, 0.1f, 100.0f)
        val viewMatrix = FloatArray(16)
        camera.getViewMatrix(viewMatrix, 0)
        val viewProjection = FloatArray(16)
        Matrix.multiplyMM(viewProjection, 0, projectionMatrix, 0, viewMatrix, 0)

        // Add program to OpenGL environment
        GLES20.glUseProgram(mProgram)

        // Enable a handle to the triangle vertices
        GLES20.glEnableVertexAttribArray(mPositionHandle)
        // Prepare the triangle coordinate data
        GLES20.glVertexAttribPointer(
                mPositionHandle, COORDS_PER_VERTEX,
                GLES20.GL_FLOAT, false,
                vertexStride, vertexBuffer)

        // Set color for drawing the triangle
        GLES20.glUniform4fv(mColorHandle, 1, color, 0)

        ShaderUtil.checkGLError(TAG, "glGetUniformLocation")
        // Apply the projection and view transformation
        // GLES20.glUniformMatrix4fv(mMVPMatrixHandle, 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(mMVPMatrixHandle, 1, false, viewProjection, 0)
        ShaderUtil.checkGLError(TAG, "glUniformMatrix4fv")
        // Draw the square
        GLES20.glDrawElements(
                GLES20.GL_TRIANGLES, drawOrder.size,
                GLES20.GL_UNSIGNED_SHORT, drawListBuffer)
        // Disable vertex array
        GLES20.glDisableVertexAttribArray(mPositionHandle)
    }

    fun updateSquareCoordinates(top: Float, bottom: Float, left: Float, right: Float) {
        if (top == 0f && bottom == 0f && left == 0f && right == 0f) return

        android.util.Log.d(TAG, "top: $top, bottom: $bottom, left: $left, right: $right")
        squareCoords = floatArrayOf(
            top, left, 0.0f,
            bottom, left, 0.0f,
            bottom, right, 0.0f,
            top, left, 0.0f,
        )

        vertexBuffer?.put(squareCoords)

        // set the buffer to read the first coordinate
        vertexBuffer?.position(0)

//        GLES20.glBufferSubData(
//            GLES20.GL_ARRAY_BUFFER, 0, numPoints * DepthRenderer.BYTES_PER_POINT, points
//        )
//        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)

        ShaderUtil.checkGLError(TAG, "Update complete")
    }

    companion object {
        private val TAG = "SquareRenderer"

        // number of coordinates per vertex in this array
        val COORDS_PER_VERTEX = 3
        var squareCoords = floatArrayOf(
                -0.5f, 0.5f, 0.0f,  // top left
                -0.5f, -0.5f, 0.0f,  // bottom left
                0.5f, -0.5f, 0.0f,  // bottom right
                0.5f, 0.5f, 0.0f) // top right
    }

    fun setColor(red: Float, green: Float, blue: Float, alpha: Float) {
        color[0] = red
        color[1] = green
        color[2] = blue
        color[3] = alpha
    }



    /**
     * Sets up the drawing object data for use in an OpenGL ES context.
     */
    init {

    }



//    @Throws(IOException::class)
//    fun createOnGlThread(context: Context?) {
//        ShaderUtil.checkGLError(DepthRenderer.TAG, "Bind")
//        val buffers = IntArray(1)
//        GLES20.glGenBuffers(1, buffers, 0)
//        arrayBuffer = buffers[0]
//        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, arrayBuffer)
//        arrayBufferSize = DepthRenderer.INITIAL_BUFFER_POINTS * DepthRenderer.BYTES_PER_POINT
//        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, arrayBufferSize, null, GLES20.GL_DYNAMIC_DRAW)
//        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
//        ShaderUtil.checkGLError(DepthRenderer.TAG, "Create")
//        val vertexShader = ShaderUtil.loadGLShader(
//            DepthRenderer.TAG,
//            context,
//            GLES20.GL_VERTEX_SHADER,
//            DepthRenderer.VERTEX_SHADER_NAME
//        )
//        val fragmentShader = ShaderUtil.loadGLShader(
//            DepthRenderer.TAG,
//            context,
//            GLES20.GL_FRAGMENT_SHADER,
//            DepthRenderer.FRAGMENT_SHADER_NAME
//        )
//        programName = GLES20.glCreateProgram()
//        GLES20.glAttachShader(programName, vertexShader)
//        GLES20.glAttachShader(programName, fragmentShader)
//        GLES20.glLinkProgram(programName)
//        GLES20.glUseProgram(programName)
//        ShaderUtil.checkGLError(DepthRenderer.TAG, "Program")
//        positionAttribute = GLES20.glGetAttribLocation(programName, "a_Position")
//        modelViewProjectionUniform =
//            GLES20.glGetUniformLocation(programName, "u_ModelViewProjection")
//        pointSizeUniform = GLES20.glGetUniformLocation(programName, "u_PointSize")
//        ShaderUtil.checkGLError(DepthRenderer.TAG, "Init complete")
//    }
}