package app.fishbuddy.ar.scanner.internal.ml

import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Combines repeated length samples of the same fish into a median plus an
 * uncertainty band — D6 / Phase 5 of `fishbuddy_android`'s scanner-accuracy plan.
 *
 * A single frame gives a single number with nothing to say about how much to
 * trust it. Master's approach, mirrored here: fix the endpoints once on the
 * armed frame, then re-sample depth at those endpoints over the following
 * frames, re-unprojecting with each frame's pose. Because the endpoints are
 * fixed, the resulting spread describes **depth and pose noise**, not
 * segmentation variance — worth stating plainly wherever the band is surfaced.
 *
 * Outliers are rejected by median absolute deviation rather than standard
 * deviation, because a couple of wild depth reads would inflate an SD-based
 * gate enough to keep themselves inside it. MAD has a ~50% breakdown point, so
 * it stays put until half the samples are bad.
 */
internal object TemporalAggregator {

    /** Rejection threshold in scaled-MAD units. Matches master's K=3. */
    const val MAD_K: Double = 3.0

    /**
     * Scale factor making the MAD a consistent estimator of σ for normally
     * distributed data (1 / Φ⁻¹(0.75)).
     */
    private const val MAD_TO_SIGMA = 1.4826

    /**
     * @param median the surviving samples' median — the reported measurement.
     * @param sigma standard deviation of the surviving samples, the ± band.
     * @param kept how many samples survived outlier rejection.
     * @param total how many were offered.
     */
    data class Aggregate(
        val median: Double,
        val sigma: Double,
        val kept: Int,
        val total: Int,
    )

    /**
     * @return the aggregate, or `null` if [samples] is empty. A single sample
     *   aggregates to itself with a σ of 0 — it is not evidence of precision,
     *   just the honest answer for one observation.
     */
    fun aggregate(samples: List<Double>, k: Double = MAD_K): Aggregate? {
        if (samples.isEmpty()) return null
        if (samples.size == 1) return Aggregate(samples[0], 0.0, 1, 1)

        val median = medianOf(samples)
        val mad = medianOf(samples.map { abs(it - median) })

        // mad == 0 means over half the samples are identical; there is no spread
        // to threshold on, so keep the samples equal to the median and drop the
        // rest as outliers.
        val kept = if (mad == 0.0) {
            samples.filter { it == median }
        } else {
            val limit = k * mad * MAD_TO_SIGMA
            samples.filter { abs(it - median) <= limit }
        }
        if (kept.isEmpty()) return Aggregate(median, 0.0, 0, samples.size)

        val keptMedian = medianOf(kept)
        val mean = kept.average()
        val variance = kept.sumOf { (it - mean) * (it - mean) } / kept.size
        return Aggregate(keptMedian, sqrt(variance), kept.size, samples.size)
    }

    private fun medianOf(values: List<Double>): Double {
        val sorted = values.sorted()
        val mid = sorted.size / 2
        return if (sorted.size % 2 == 1) {
            sorted[mid]
        } else {
            (sorted[mid - 1] + sorted[mid]) / 2.0
        }
    }
}
