package app.fishbuddy.ar.scanner.internal.view

import android.app.Activity
import android.content.Context
import app.fishbuddy.ar.scanner.internal.ScanFlags
import app.fishbuddy.ar.scanner.internal.diagnostics.ScanValidationLogger
import android.graphics.Bitmap
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.PixelCopy
import android.view.View
import app.fishbuddy.ar.scanner.ARClassification
import app.fishbuddy.ar.scanner.ARScanOutcome
import app.fishbuddy.ar.scanner.ARScannerConfiguration
import app.fishbuddy.ar.scanner.ARScannerController
import app.fishbuddy.ar.scanner.ARScannerError
import app.fishbuddy.ar.scanner.ARScannerGestures
import app.fishbuddy.ar.scanner.ARScannerState
import app.fishbuddy.ar.scanner.ControllerEngine
import app.fishbuddy.ar.scanner.internal.ar.common.helpers.DisplayRotationHelper
import app.fishbuddy.ar.scanner.internal.ar.common.rendering.DepthRenderer
import app.fishbuddy.ar.scanner.internal.ar.rawdepth.DepthScenePoints
import app.fishbuddy.ar.scanner.internal.license.LicenseSession
import app.fishbuddy.ar.scanner.internal.ml.AutoMeasurePipeline
import app.fishbuddy.ar.scanner.internal.ml.ImageClassifier
import app.fishbuddy.ar.scanner.internal.ml.Segmenter
import app.fishbuddy.ar.scanner.internal.telemetry.TelemetryUploader
import app.fishbuddy.ar.scanner.ARScannerDataContribution
import app.fishbuddy.ar.scanner.internal.shared.common.TapHelper
import app.fishbuddy.ar.scanner.internal.shared.rendering.BackgroundRenderer
import app.fishbuddy.ar.scanner.internal.shared.rendering.DotRenderer
import app.fishbuddy.ar.scanner.internal.shared.rendering.PlaneRenderer
import app.fishbuddy.ar.scanner.internal.shared.rendering.PointCloudRenderer
import android.util.Size
import com.google.ar.core.Anchor
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Camera
import com.google.ar.core.CameraConfig
import com.google.ar.core.CameraConfigFilter
import com.google.ar.core.Config
import com.google.ar.core.DepthPoint
import com.google.ar.core.Frame
import com.google.ar.core.InstantPlacementPoint
import com.google.ar.core.Plane
import com.google.ar.core.Point
import com.google.ar.core.Session
import com.google.ar.core.TrackingState
import com.google.ar.core.exceptions.CameraNotAvailableException
import com.google.ar.core.exceptions.UnavailableException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * The internal AR + GL driver behind [app.fishbuddy.ar.scanner.ARScannerView].
 *
 * Owns the ARCore [Session], the [AutoFitGLSurfaceView], every renderer, and the
 * [ImageClassifier]. Bridged to public-API [ARScannerController] via [ControllerEngine].
 *
 * Lifecycle: caller (the Compose hosting layer) MUST invoke [onResume]/[onPause]/[onDestroy]
 * in step with the hosting lifecycle. Session resume/close are off-loaded to IO so the
 * UI thread stays free during heavy native init/teardown.
 */
internal class ARScannerViewController(
    context: Context,
    private val configuration: ARScannerConfiguration,
    private val controller: ARScannerController,
    private val scope: CoroutineScope,
    private val onScan: suspend (ARScanOutcome) -> Unit,
) : GLSurfaceView.Renderer, ControllerEngine {

    private val appContext = context.applicationContext

    private val tapHelper = TapHelper(context)
    private val displayRotationHelper = DisplayRotationHelper(context)
    private val backgroundRenderer = BackgroundRenderer()
    private val dotRenderer = DotRenderer()
    private val pointCloudRenderer = PointCloudRenderer()
    private val planeRenderer = PlaneRenderer()
    private val depthRenderer = DepthRenderer()
    private val classifier: ImageClassifier by lazy { ImageClassifier(appContext) }
    private val segmenter: Segmenter by lazy { Segmenter(appContext) }
    private val autoPipeline: AutoMeasurePipeline by lazy {
        // No-op unless a debug build set ScanValidationLogger.enabled; without
        // this the harness has nowhere to write and silently stays inert.
        ScanValidationLogger.init(appContext)
        AutoMeasurePipeline(classifier = classifier, segmenter = segmenter)
    }
    private val telemetryUploader by lazy { TelemetryUploader() }
    private val licenseSession: LicenseSession by lazy {
        LicenseSession(
            context = appContext,
            licenseKey = configuration.license.key,
            backendURL = configuration.licenseBackendURL,
            bundleId = appContext.packageName,
        )
    }

    private val anchors = mutableListOf<ColoredAnchor>()
    private val anchorMatrix = FloatArray(16)
    private val defaultAnchorColor = floatArrayOf(0f, 255f, 0f, 0f)

    private val sessionLock = Any()
    private var session: Session? = null
    private val sessionPaused = AtomicBoolean(true)
    private var refocusJob: Job? = null

    private val captureRequested = AtomicBoolean(false)

    /**
     * D6 — a scan whose endpoints are fixed and which is still collecting depth
     * samples on subsequent frames. Null unless
     * [ScanFlags.scanTemporalAggregationEnabled] is on. Only touched from the GL
     * thread.
     */
    private var pendingAggregation: AutoMeasurePipeline.ArmedScan? = null

    /** D9 — whether [pendingMeasurementMeters] rests on an unrefined pose. */
    private var pendingMeasurementIsCoarse: Boolean = false

    /** Snapshot of anchor poses taken when [captureAndScan] was called. */
    @Volatile
    private var pendingMeasurementMeters: Double? = null

    private val glView: AutoFitGLSurfaceView = AutoFitGLSurfaceView(context).apply {
        // No aspect-ratio lock — fill the parent. The cropping pipeline inside
        // AutoMeasurePipeline handles whatever ratio the camera + display land on.
        // Constraining to 3:4 here letterboxed the camera into a portrait box and
        // wasted screen real estate on phones where the available space is
        // taller-than-3:4.
        preserveEGLContextOnPause = true
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        setRenderer(this@ARScannerViewController)
        renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        setWillNotDraw(false)
        setOnTouchListener(tapHelper)
    }

    val view: View get() = glView

    init {
        controller.engine = this
    }

    // === Lifecycle ===

    fun onResume(activity: Activity?) {
        if (session == null) {
            controller.updateState(ARScannerState.Initializing)
            if (!ensureArCoreReady(activity)) return
            val created = createAndConfigureSession() ?: return
            synchronized(sessionLock) { session = created }
        }
        try {
            synchronized(sessionLock) { session?.resume() }
            sessionPaused.set(false)
            displayRotationHelper.onResume()
            glView.onResume()
            controller.updateState(ARScannerState.Ready)
            // Nudge autofocus after the camera HAL has had a moment to settle —
            // matches Fishbuddy's refocusJob. Without this, the first scan
            // sometimes captures a slightly out-of-focus frame after a config
            // change because ARCore doesn't always re-trigger AF on its own.
            scheduleRefocus()
        } catch (e: CameraNotAvailableException) {
            controller.updateState(
                ARScannerState.Failed(
                    ARScannerError.CameraUnavailable("Camera not available: ${e.message}"),
                ),
            )
        }
    }

    fun onPause() {
        sessionPaused.set(true)
        refocusJob?.cancel()
        refocusJob = null
        // The frame loop stops here, so an armed scan would otherwise resume
        // sampling on resume against a completely different view.
        pendingAggregation = null
        try {
            displayRotationHelper.onPause()
            glView.onPause()
        } catch (e: Exception) {
            Log.d(TAG, "onPause: ${e.message}")
        }
        scope.launch(Dispatchers.IO) {
            synchronized(sessionLock) {
                runCatching { session?.pause() }
            }
        }
    }

    private fun scheduleRefocus() {
        refocusJob?.cancel()
        refocusJob = scope.launch {
            delay(REFOCUS_DELAY_MS)
            if (sessionPaused.get()) return@launch
            synchronized(sessionLock) {
                val s = session ?: return@launch
                try {
                    val cfg = s.config
                    cfg.focusMode = Config.FocusMode.AUTO
                    s.configure(cfg)
                    Log.d(TAG, "refocus nudge")
                } catch (e: Exception) {
                    Log.d(TAG, "refocus failed: ${e.message}")
                }
            }
        }
    }

    fun onDestroy() {
        controller.engine = null
        val toClose: Session?
        synchronized(sessionLock) {
            toClose = session
            session = null
            sessionPaused.set(true)
        }
        CoroutineScope(Dispatchers.IO).launch {
            runCatching { toClose?.close() }
            runCatching { classifier.close() }
        }
    }

    // === ControllerEngine ===

    override fun captureAndScan() {
        if (controller.state.value == ARScannerState.Scanning) return
        // Snapshot anchor poses now — by the time the GL thread captures the frame,
        // the user may have lifted the device and tracking will have drifted.
        pendingMeasurementMeters = measureBetweenAnchors()
        // License gate runs off the calling thread; the GL thread only picks up
        // captureRequested once validation succeeds. Cache hits return without
        // a network roundtrip, so the warm path stays effectively synchronous.
        scope.launch {
            if (ensureLicensed()) captureRequested.set(true)
        }
    }

    private suspend fun ensureLicensed(): Boolean {
        return try {
            licenseSession.ensureValidJWT()
            true
        } catch (e: Throwable) {
            // v1 collapses every license failure (offline, 403, expired JWT, …)
            // into ARScannerError.LicenseInvalid. The richer mapping the spec
            // sketches in §9 is post-v1 once host apps need to differentiate.
            Log.w(TAG, "license validation failed", e)
            controller.updateState(
                ARScannerState.Failed(
                    ARScannerError.LicenseInvalid(e.message ?: e::class.java.simpleName),
                ),
            )
            false
        }
    }

    private fun measureBetweenAnchors(): Double? {
        val tracking = synchronized(anchors) {
            anchors.filter { it.anchor.trackingState == TrackingState.TRACKING }
        }
        val snapshot = tracking.map { it.anchor.pose }
        if (snapshot.size < 2) return null

        // D9. An Instant Placement anchor's pose is seeded at
        // INSTANT_PLACEMENT_APPROX_DISTANCE and only corrected once ARCore has the
        // parallax to refine it. Until then the distance between two such anchors
        // scales with that guess, so the measurement can be confidently wrong.
        // Record it rather than silently reporting it as a tracked measurement.
        pendingMeasurementIsCoarse = tracking.take(2).any { it.isApproximate() }
        if (pendingMeasurementIsCoarse) {
            Log.d(TAG, "manual measurement is coarse — instant placement not yet refined")
        }

        val a = snapshot[0]
        val b = snapshot[1]
        val dx = a.tx() - b.tx()
        val dy = a.ty() - b.ty()
        val dz = a.tz() - b.tz()
        val meters = kotlin.math.sqrt(dx * dx + dy * dy + dz * dz).toDouble()
        // Match the sanity cap from Fishbuddy's depth pipeline: anchor distances
        // above 2 m are almost certainly tracking errors — discard rather than report.
        return if (meters > MAX_PLAUSIBLE_LENGTH_METERS) null else meters
    }

    override suspend fun classify(bitmap: Bitmap) {
        if (!ensureLicensed()) return
        runClassify(bitmap)
    }

    override fun reset() {
        synchronized(anchors) {
            anchors.forEach { runCatching { it.anchor.detach() } }
            anchors.clear()
        }
        // Abandon an in-flight D6 aggregation. Without this the frame loop would
        // keep sampling a fish the user has already reset away from, and emit an
        // outcome for it. Return to Ready, since the scan is no longer running.
        if (pendingAggregation != null) {
            pendingAggregation = null
            controller.updateState(ARScannerState.Ready)
        }
    }

    // === GLSurfaceView.Renderer ===

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.1f, 0.1f, 0.1f, 1f)
        try {
            backgroundRenderer.createOnGlThread(appContext)
            dotRenderer.createOnGlThread(appContext, "models/dot.obj", "models/dot.png")
            dotRenderer.setMaterialProperties(0.0f, 2.0f, 0.5f, 6.0f)
            pointCloudRenderer.createOnGlThread(appContext)
            planeRenderer.createOnGlThread(appContext, "models/trigrid.png")
            depthRenderer.createOnGlThread(appContext)
        } catch (e: IOException) {
            Log.e(TAG, "Failed to read shader/model asset", e)
        }
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        displayRotationHelper.onSurfaceChanged(width, height)
        GLES20.glViewport(0, 0, width, height)
        depthRenderer.setViewportSize(width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        val localSession = synchronized(sessionLock) { session } ?: return
        if (sessionPaused.get()) return

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        try {
            val frame: Frame
            synchronized(sessionLock) {
                if (session == null || sessionPaused.get()) return
                displayRotationHelper.updateSessionIfNeeded(localSession)
                localSession.setCameraTextureName(backgroundRenderer.textureId)
                frame = localSession.update()
            }

            val camera = frame.camera
            backgroundRenderer.draw(frame)

            if (camera.trackingState != TrackingState.TRACKING) return

            val projMatrix = FloatArray(16)
            camera.getProjectionMatrix(projMatrix, 0, 0.1f, 100.0f)
            val viewMatrix = FloatArray(16)
            camera.getViewMatrix(viewMatrix, 0)
            val colorCorrection = FloatArray(4)
            frame.lightEstimate.getColorCorrection(colorCorrection, 0)

            // Dense raw-depth point cloud — the dotted texture covering the fish
            // and floor. This is the SDK's primary scanning-feedback visual; the
            // PlaneRenderer trigrid and ARCore feature-point cloud are NOT drawn
            // because they pile additional textures on top and crowd the view.
            // (The renderers stay in the codebase as opt-in extras for customers
            // who want them, but the SDK's default render loop uses depth only.)
            if (localSession.config.depthMode == Config.DepthMode.RAW_DEPTH_ONLY) {
                runCatching {
                    val depthImage = frame.acquireRawDepthImage16Bits()
                    val confidenceImage = frame.acquireRawDepthConfidenceImage()
                    try {
                        val modelMatrix = FloatArray(16)
                        camera.pose.toMatrix(modelMatrix, 0)
                        val pointBuffer = DepthScenePoints.build(
                            depth = depthImage,
                            confidence = confidenceImage,
                            cameraTextureIntrinsics = camera.textureIntrinsics,
                            modelMatrix = modelMatrix,
                        )
                        depthRenderer.update(pointBuffer)
                        depthRenderer.draw(camera)
                    } finally {
                        depthImage.close()
                        confidenceImage.close()
                    }
                }
            }

            handleTap(frame, camera)

            synchronized(anchors) {
                for (anchor in anchors) {
                    if (anchor.anchor.trackingState != TrackingState.TRACKING) continue
                    anchor.anchor.pose.toMatrix(anchorMatrix, 0)
                    dotRenderer.updateModelMatrix(anchorMatrix, 1.0f)
                    dotRenderer.draw(viewMatrix, projMatrix, colorCorrection, anchor.color)
                }
            }

            // D6 — an armed scan is still gathering samples. Keep re-measuring its
            // fixed endpoints against each new frame until the sample target or the
            // frame budget is hit, then emit. Runs before the capture check so a
            // second shutter press can't interleave with an in-flight aggregation.
            val armed = pendingAggregation
            if (armed != null) {
                val depthMode = synchronized(sessionLock) {
                    session?.config?.depthMode ?: Config.DepthMode.DISABLED
                }
                autoPipeline.sampleAgain(armed, frame, depthMode)
                if (armed.isComplete) {
                    pendingAggregation = null
                    emitOutcome(autoPipeline.finish(armed))
                }
                return
            }

            // A capture was requested — pick a path based on how many anchors are placed.
            if (captureRequested.compareAndSet(true, false)) {
                val anchorCount = synchronized(anchors) {
                    anchors.count { it.anchor.trackingState == TrackingState.TRACKING }
                }
                val depthMode = synchronized(sessionLock) {
                    session?.config?.depthMode ?: Config.DepthMode.DISABLED
                }
                // Cameras report sensor coords; phones are typically held portrait
                // (sensor rotated 90° from display). Pass this through so the
                // classifier sees a portrait-oriented fish — matches Fishbuddy.
                val cameraId = localSession.cameraConfig.cameraId
                val orientationDegrees = runCatching {
                    displayRotationHelper.getCameraSensorToDisplayRotation(cameraId)
                }.getOrDefault(0)
                runCaptureForFrame(frame, anchorCount, depthMode, orientationDegrees)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "GL thread exception", t)
        }
    }

    // === Internals ===

    private fun ensureArCoreReady(activity: Activity?): Boolean {
        return try {
            val availability = ArCoreApk.getInstance().checkAvailability(appContext)
            if (!availability.isSupported) {
                controller.updateState(
                    ARScannerState.Failed(
                        ARScannerError.ArCoreUnavailable("ARCore not supported on this device"),
                    ),
                )
                return false
            }
            if (availability == ArCoreApk.Availability.SUPPORTED_NOT_INSTALLED ||
                availability == ArCoreApk.Availability.SUPPORTED_APK_TOO_OLD
            ) {
                if (configuration.showsArCoreInstallPrompt && activity != null) {
                    val status = ArCoreApk.getInstance()
                        .requestInstall(activity, true)
                    if (status == ArCoreApk.InstallStatus.INSTALL_REQUESTED) {
                        controller.updateState(
                            ARScannerState.Failed(
                                ARScannerError.ArCoreUnavailable("ARCore install requested"),
                            ),
                        )
                        return false
                    }
                } else {
                    controller.updateState(
                        ARScannerState.Failed(
                            ARScannerError.ArCoreUnavailable("ARCore not installed"),
                        ),
                    )
                    return false
                }
            }
            true
        } catch (e: UnavailableException) {
            controller.updateState(
                ARScannerState.Failed(
                    ARScannerError.ArCoreUnavailable("ARCore check failed: ${e.message}"),
                ),
            )
            false
        }
    }

    private fun createAndConfigureSession(): Session? {
        return try {
            val s = Session(appContext)

            // Pick the best 4:3 CPU/texture camera config available. ARCore's default
            // picks the lowest, so without this the camera image comes in at 640×480
            // on most phones — fine for AR tracking but coarse for ML inference.
            val filter = CameraConfigFilter(s)
            val configs = s.getSupportedCameraConfigs(filter)
            val bestConfig = selectBestConfigForPortrait(configs)
            if (bestConfig != null) {
                Log.d(
                    TAG,
                    "camera config: image=${bestConfig.imageSize} texture=${bestConfig.textureSize}" +
                        " fps=${bestConfig.fpsRange}",
                )
                s.cameraConfig = bestConfig
            }

            val cfg = s.config
            cfg.focusMode = Config.FocusMode.AUTO
            // Prefer RAW_DEPTH_ONLY when the device supports it — the auto-measure
            // pipeline needs raw depth + confidence images. Matches Fishbuddy's
            // production AR session config.
            cfg.depthMode = when {
                s.isDepthModeSupported(Config.DepthMode.RAW_DEPTH_ONLY) -> Config.DepthMode.RAW_DEPTH_ONLY
                s.isDepthModeSupported(Config.DepthMode.AUTOMATIC) -> Config.DepthMode.AUTOMATIC
                else -> Config.DepthMode.DISABLED
            }
            // Enable instant placement so hitTestInstantPlacement can land
            // anchors at the actual tapped surface depth, not just on the
            // detected plane beneath it. Without this, anchors fall through
            // a fish onto the floor below it.
            cfg.instantPlacementMode = Config.InstantPlacementMode.LOCAL_Y_UP
            Log.d(TAG, "session depthMode=${cfg.depthMode} instantPlacement=${cfg.instantPlacementMode}")
            cfg.cloudAnchorMode = Config.CloudAnchorMode.DISABLED
            s.configure(cfg)
            s
        } catch (e: Exception) {
            controller.updateState(
                ARScannerState.Failed(
                    ARScannerError.ArCoreUnavailable("Session create failed: ${e.message}"),
                ),
            )
            null
        }
    }

    private fun handleTap(frame: Frame, camera: Camera) {
        if (configuration.enabledGestures == ARScannerGestures.None) return
        val tap = tapHelper.poll() ?: return
        if (camera.trackingState != TrackingState.TRACKING) return

        // First choice: instant placement. Uses raw depth at the tapped pixel,
        // so a tap on a fish lands on the *fish* — not the floor plane below it.
        // The approximate-distance hint is just for the initial pose estimate
        // before ARCore refines via depth.
        val instantHits = runCatching {
            frame.hitTestInstantPlacement(tap.x, tap.y, INSTANT_PLACEMENT_APPROX_DISTANCE)
        }.getOrDefault(emptyList())
        val instantHit = instantHits.firstOrNull()

        // Fallback: traditional hitTest. Prefer DepthPoint > oriented Point > Plane.
        val acceptedHit = instantHit ?: run {
            val hits = frame.hitTest(tap)
            val depthHit = hits.firstOrNull { it.trackable is DepthPoint }
            val pointHit = hits.firstOrNull { hit ->
                val t = hit.trackable
                t is Point && t.orientationMode == Point.OrientationMode.ESTIMATED_SURFACE_NORMAL
            }
            val planeHit = hits.firstOrNull { hit ->
                val t = hit.trackable
                t is Plane && t.isPoseInPolygon(hit.hitPose)
            }
            depthHit ?: pointHit ?: planeHit
        } ?: return

        synchronized(anchors) {
            if (anchors.size >= configuration.measurementNodeCount) {
                anchors.first().anchor.detach()
                anchors.removeAt(0)
            }
            anchors.add(
                ColoredAnchor(
                    anchor = acceptedHit.createAnchor(),
                    color = defaultAnchorColor,
                    instantPlacementPoint = acceptedHit.trackable as? InstantPlacementPoint,
                ),
            )
        }
        Log.d(
            TAG,
            "anchor placed via ${acceptedHit.trackable.javaClass.simpleName} " +
                "(${if (instantHit != null) "instant" else "fallback"})",
        )
    }

    /**
     * Runs the appropriate capture pipeline on the GL thread. Heavy ML work happens
     * here synchronously — the GL view freezes for ~1–2 s during inference, which is
     * the desired UX (user sees the captured frame held still while we process it).
     */
    private fun runCaptureForFrame(
        frame: Frame,
        anchorCount: Int,
        depthMode: Config.DepthMode,
        orientationDegrees: Int,
    ) {
        controller.updateState(ARScannerState.Scanning)
        try {
            val outcome: ARScanOutcome = if (anchorCount >= 2) {
                // Manual mode — user placed head/tail. Capture via PixelCopy on main
                // (works even when depth isn't supported) and use the snapshotted
                // anchor distance computed at captureAndScan() time.
                val bitmap = capturePixelsBlocking() ?: return failCapture("GL surface not laid out")
                runClassifyAndEmit(bitmap, pendingMeasurementMeters, pendingMeasurementIsCoarse)
            } else if (depthMode != Config.DepthMode.DISABLED) {
                // Auto mode — segmentation finds endpoints, raw depth measures them.
                var armedScan: AutoMeasurePipeline.ArmedScan? = null
                val singleFrame = autoPipeline.run(
                    frame,
                    depthMode,
                    configuration.scoreThreshold,
                    orientationDegrees,
                    armedOut = if (ScanFlags.scanTemporalAggregationEnabled) {
                        { armedScan = it }
                    } else {
                        null
                    },
                ) ?: return failCapture("Auto-measure produced no outcome")

                // D6 on: hold the outcome back and let the frame loop gather more
                // samples before emitting. State stays Scanning until then, which
                // is what the host app already shows during inference.
                val toAggregate = armedScan
                if (toAggregate != null) {
                    pendingAggregation = toAggregate
                    pendingMeasurementMeters = null
                    return
                }
                singleFrame
            } else {
                return failCapture("Place 2 anchors first — auto-measure needs depth-capable device")
            }
            emitOutcome(outcome)
        } catch (e: ARScannerError) {
            controller.updateState(ARScannerState.Failed(e))
        } catch (t: Throwable) {
            Log.e(TAG, "Capture pipeline error", t)
            controller.updateState(
                ARScannerState.Failed(ARScannerError.ModelLoad("Capture failed: ${t.message}", t)),
            )
        }
    }

    /**
     * Deliver a finished outcome to the host app and return the scanner to Ready.
     * Shared by the single-frame path and the D6 aggregated path.
     */
    private fun emitOutcome(outcome: ARScanOutcome) {
        pendingMeasurementMeters = null
        pendingMeasurementIsCoarse = false
        scope.launch {
            runCatching { onScan(outcome) }
                .onFailure { Log.e(TAG, "onScan callback threw", it) }
            maybeUploadTelemetry(outcome)
        }
        controller.updateState(ARScannerState.Ready)
    }

    private fun runClassifyAndEmit(
        bitmap: Bitmap,
        measurementMeters: Double?,
        measurementIsCoarse: Boolean = false,
    ): ARScanOutcome {
        val all = classifier.classify(bitmap)
        val top = all.firstOrNull()
            ?: ARClassification(label = "unknown", confidence = 0.0)
        val aboveThreshold = all.filter { it.confidence >= configuration.scoreThreshold }
        return ARScanOutcome(
            image = bitmap,
            topClassification = top,
            allClassifications = aboveThreshold,
            measurementMeters = measurementMeters,
            // Only meaningful when a measurement exists; false otherwise.
            measurementIsCoarse = measurementMeters != null && measurementIsCoarse,
        )
    }

    private fun failCapture(message: String) {
        Log.w(TAG, message)
        controller.updateState(
            ARScannerState.Failed(ARScannerError.CameraUnavailable(message)),
        )
    }

    /**
     * Fires the telemetry upload pipeline when the consumer has opted in via
     * `ARScannerDataContribution.Enabled`. Runs after `onScan` so the
     * consumer's own consent UI (if any) has already had a chance to gate it,
     * but the consent callback in [ARScannerDataContribution.Enabled] is the
     * authoritative gate — the SDK only uploads when it returns `true`.
     *
     * Failures are silent (logged at WARN inside `TelemetryUploader.upload`);
     * a flaky network never breaks the scan flow.
     */
    private suspend fun maybeUploadTelemetry(outcome: ARScanOutcome) {
        val enabled = configuration.dataContribution as? ARScannerDataContribution.Enabled
            ?: return
        val consentGranted = runCatching { enabled.consent() }
            .onFailure { Log.w(TAG, "consent callback threw", it) }
            .getOrDefault(false)
        if (!consentGranted) return
        val metadata = runCatching { enabled.metadata() }
            .onFailure { Log.w(TAG, "metadata callback threw", it) }
            .getOrNull()
        telemetryUploader.upload(
            outcome = outcome,
            metadata = metadata,
            license = configuration.license,
        )
    }

    /**
     * Synchronous PixelCopy wrapper for use on the GL thread. PixelCopy itself is
     * async, but we block this thread until it completes — the GL thread is the
     * rendering thread, not the UI thread, so blocking it briefly is fine and is
     * how the manual capture path stays single-threaded with the auto pipeline.
     */
    private fun capturePixelsBlocking(): Bitmap? {
        val w = glView.width
        val h = glView.height
        if (w <= 0 || h <= 0) return null
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val latch = java.util.concurrent.CountDownLatch(1)
        var success = false
        val handler = Handler(Looper.getMainLooper())
        try {
            PixelCopy.request(
                glView,
                bitmap,
                { result -> success = result == PixelCopy.SUCCESS; latch.countDown() },
                handler,
            )
        } catch (e: Exception) {
            Log.w(TAG, "PixelCopy request threw", e)
            return null
        }
        latch.await(2, java.util.concurrent.TimeUnit.SECONDS)
        return if (success) bitmap else null
    }

    /** Used by [ControllerEngine.classify] — still-image input from a gallery / file. */
    private suspend fun runClassify(bitmap: Bitmap) {
        controller.updateState(ARScannerState.Scanning)
        try {
            val all = withContext(Dispatchers.Default) {
                classifier.classify(bitmap)
            }
            val top = all.firstOrNull()
                ?: ARClassification(label = "unknown", confidence = 0.0)
            val aboveThreshold = all.filter { it.confidence >= configuration.scoreThreshold }
            val outcome = ARScanOutcome(
                image = bitmap,
                topClassification = top,
                allClassifications = aboveThreshold,
                measurementMeters = null,
            )
            onScan(outcome)
            controller.updateState(ARScannerState.Ready)
        } catch (e: ARScannerError) {
            controller.updateState(ARScannerState.Failed(e))
        } catch (e: Exception) {
            controller.updateState(
                ARScannerState.Failed(ARScannerError.ModelLoad("Classification failed", e)),
            )
        }
    }

    /**
     * Picks the best camera config for 4:3 portrait scanning — distilled from
     * Fishbuddy's `selectBestConfigForPortrait` in ScanArFragment. Priority order:
     *   1. maximise min(effective43(image), effective43(texture)) — avoid bottlenecks
     *   2. prefer configs whose image/texture are closest to native 4:3
     *   3. prefer higher upper FPS
     *   4. larger raw areas as tie-break
     */
    private fun selectBestConfigForPortrait(configs: List<CameraConfig>): CameraConfig? {
        if (configs.isEmpty()) return null

        data class Score(
            val cfg: CameraConfig,
            val effMin: Double,
            val deltaSum: Float,
            val fpsUpper: Int,
            val totalArea: Long,
        )

        fun Size.aspect() = width.toFloat() / height.toFloat()
        fun Size.effective43Area(): Double {
            val w = width.toDouble()
            val h = height.toDouble()
            val target = 4.0 / 3.0
            return if (w / h >= target) target * h * h else (1.0 / target) * w * w
        }
        fun Size.aspectDelta() = kotlin.math.abs(aspect() - 4f / 3f)

        val scored = configs.map { cfg ->
            val img = cfg.imageSize
            val tex = cfg.textureSize
            Score(
                cfg = cfg,
                effMin = minOf(img.effective43Area(), tex.effective43Area()),
                deltaSum = img.aspectDelta() + tex.aspectDelta(),
                fpsUpper = cfg.fpsRange.upper,
                totalArea = img.width.toLong() * img.height.toLong() +
                    tex.width.toLong() * tex.height.toLong(),
            )
        }
        return scored.reduce { acc, s ->
            when {
                s.effMin != acc.effMin -> if (s.effMin > acc.effMin) s else acc
                s.deltaSum != acc.deltaSum -> if (s.deltaSum < acc.deltaSum) s else acc
                s.fpsUpper != acc.fpsUpper -> if (s.fpsUpper > acc.fpsUpper) s else acc
                else -> if (s.totalArea > acc.totalArea) s else acc
            }
        }.cfg
    }

    private companion object {
        const val TAG = "ARScannerViewCtl"

        /** Same sanity cap Fishbuddy's existing depth pipeline uses (DepthData). */
        const val MAX_PLAUSIBLE_LENGTH_METERS = 2.0

        /** Initial ARCore instant-placement guess for the tapped surface distance. */
        const val INSTANT_PLACEMENT_APPROX_DISTANCE = 1.0f

        /** Match Fishbuddy's refocusJob — wait ~0.7 s after resume to nudge AF. */
        const val REFOCUS_DELAY_MS = 700L
    }

    private class ColoredAnchor(
        val anchor: Anchor,
        val color: FloatArray,
        /**
         * The Instant Placement point this anchor came from, when it did. Kept so
         * [measureBetweenAnchors] can tell a refined pose from one still sitting at
         * the approximate-distance guess (D9).
         */
        val instantPlacementPoint: InstantPlacementPoint? = null,
    ) {
        /** True while this anchor's pose is still ARCore's initial estimate. */
        fun isApproximate(): Boolean =
            instantPlacementPoint?.trackingMethod ==
                InstantPlacementPoint.TrackingMethod.SCREENSPACE_WITH_APPROXIMATE_DISTANCE
    }
}
