package app.fishbuddy.ar.scanner.internal.license

/**
 * PEM-encoded EC P-256 public key for verifying license JWTs issued by
 * `https://sdk.fiskher.no/v1/license/validate`. Matches KMS key
 * `projects/fiskher-sdk-production/locations/europe-west3/keyRings/fish-vision-ar/cryptoKeys/license-jwt-signing/cryptoKeyVersions/1`.
 *
 * Must be byte-for-byte identical to the iOS SDK's `EmbeddedPublicKey.PEM`
 * (both verify against the same JWTs).
 *
 * Rotation: backend rotates KMS → curl `/v1/keys/public` → paste new PEM → cut a new SDK release.
 */
internal object EmbeddedPublicKey {

    const val PEM: String =
        "-----BEGIN PUBLIC KEY-----\n" +
            "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEdiCNdmaRANfMSEU/aMHCdjypADBb\n" +
            "P/M7z55Wx3B1kGMS3rO/joFYysp7LOA+5KF/yGQzx064Zcc8AF171blmcA==\n" +
            "-----END PUBLIC KEY-----\n"
}
