/*
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package app.fishbuddy.ar.scanner.internal.shared.common;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/** Helper to ask camera permission. */
public final class CameraPermissionHelper {
  static final int CAMERA_PERMISSION_CODE = 0;
  static final String CAMERA_PERMISSION = Manifest.permission.CAMERA;
  static final String LOCATION_COARSE_PERMISSION = Manifest.permission.ACCESS_COARSE_LOCATION;
  static final String LOCATION_FINE_PERMISSION = Manifest.permission.ACCESS_FINE_LOCATION;
  static final String ACCESS_MEDIA_LOCATION = Manifest.permission.ACCESS_MEDIA_LOCATION;

  /** Check to see we have the necessary permissions for this app. */
  public static boolean hasRequiredPermissions(Activity activity) {
    return ContextCompat.checkSelfPermission(activity, CAMERA_PERMISSION)
            == PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(activity, ACCESS_MEDIA_LOCATION)
            == PackageManager.PERMISSION_GRANTED && (ContextCompat.checkSelfPermission(activity, LOCATION_COARSE_PERMISSION)
            == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(activity, LOCATION_FINE_PERMISSION)
            == PackageManager.PERMISSION_GRANTED);
  }
  public static boolean hasRequiredCameraPermissions(Activity activity) {
    return ContextCompat.checkSelfPermission(activity, CAMERA_PERMISSION)
            == PackageManager.PERMISSION_GRANTED;
  }

  public static boolean hasRequiredLocationPermissions(Activity activity) {
    return (ContextCompat.checkSelfPermission(activity, LOCATION_COARSE_PERMISSION)
            == PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(activity, LOCATION_FINE_PERMISSION)
            == PackageManager.PERMISSION_GRANTED);
  }

  public static boolean hasRequiredMediaPermissions(Activity activity) {
    return (ContextCompat.checkSelfPermission(activity, ACCESS_MEDIA_LOCATION)
            == PackageManager.PERMISSION_GRANTED);
  }

  /** Check to see we have the necessary permissions for this app, and ask for them if we don't. */
  public static void requestPermissions(Activity activity) {
    ActivityCompat.requestPermissions(
        activity, new String[] {CAMERA_PERMISSION, LOCATION_FINE_PERMISSION, LOCATION_COARSE_PERMISSION, ACCESS_MEDIA_LOCATION}, CAMERA_PERMISSION_CODE);
  }

  public static void requestCameraPermissions(Activity activity) {
    ActivityCompat.requestPermissions(
            activity, new String[] {CAMERA_PERMISSION}, CAMERA_PERMISSION_CODE);
  }

  /** Check to see we have the necessary permissions for this app, and ask for them if we don't. */
  public static void requestLocationPermissions(Activity activity) {
    ActivityCompat.requestPermissions(
            activity, new String[] {LOCATION_FINE_PERMISSION, LOCATION_COARSE_PERMISSION}, CAMERA_PERMISSION_CODE);
  }

  public static void requestMediaPermissions(Activity activity) {
    ActivityCompat.requestPermissions(
            activity, new String[] {ACCESS_MEDIA_LOCATION}, CAMERA_PERMISSION_CODE);
  }

  /** Check to see if we need to show the rationale for this permission. */
  public static boolean shouldShowRequestPermissionRationale(Activity activity) {
    return ActivityCompat.shouldShowRequestPermissionRationale(activity, CAMERA_PERMISSION) ||
            ActivityCompat.shouldShowRequestPermissionRationale(activity, LOCATION_FINE_PERMISSION) ||
            ActivityCompat.shouldShowRequestPermissionRationale(activity, LOCATION_COARSE_PERMISSION) ||
            ActivityCompat.shouldShowRequestPermissionRationale(activity, ACCESS_MEDIA_LOCATION);
  }

  /** Check to see if we need to show the rationale for this permission. */
  public static boolean shouldShowRequestPermissionRationaleLocation(Activity activity) {
    return ActivityCompat.shouldShowRequestPermissionRationale(activity, LOCATION_FINE_PERMISSION) ||
            ActivityCompat.shouldShowRequestPermissionRationale(activity, LOCATION_COARSE_PERMISSION);
  }

  /** Launch Application Setting to grant permission. */
  public static void launchPermissionSettings(Activity activity) {
    Intent intent = new Intent();
    intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
    intent.setData(Uri.fromParts("package", activity.getPackageName(), null));
    activity.startActivity(intent);
  }
}
