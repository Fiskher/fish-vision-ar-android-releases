package app.fishbuddy.ar.scanner.internal.ml

import android.content.res.AssetManager
import java.io.File
import java.io.FileInputStream
import java.io.RandomAccessFile
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/**
 * A handle to a TFLite model wherever it happens to live — internal storage
 * (downloaded), external scoped storage (adb push), or the consumer's `assets/`
 * (bundled by the consumer app). All three paths are interchangeable from the
 * inference layer's point of view; this interface hides the difference.
 */
internal sealed interface ModelSource {
    val displayName: String
    fun mapToBuffer(): MappedByteBuffer

    class FromFile(val file: File) : ModelSource {
        override val displayName: String get() = file.absolutePath
        override fun mapToBuffer(): MappedByteBuffer =
            RandomAccessFile(file, "r").use { raf ->
                raf.channel.map(FileChannel.MapMode.READ_ONLY, 0, raf.length())
            }
    }

    /**
     * Reads a model out of an [AssetManager]. The asset MUST be uncompressed
     * — the library's manifest sets `noCompress` for `.tflite`, and that
     * propagates into consumer apps via AAR merging, so this is satisfied
     * automatically.
     */
    class FromAsset(
        private val assetManager: AssetManager,
        private val path: String,
    ) : ModelSource {
        override val displayName: String get() = "asset:$path"
        override fun mapToBuffer(): MappedByteBuffer {
            val afd = assetManager.openFd(path)
            return FileInputStream(afd.fileDescriptor).channel.map(
                FileChannel.MapMode.READ_ONLY,
                afd.startOffset,
                afd.declaredLength,
            )
        }
    }
}
