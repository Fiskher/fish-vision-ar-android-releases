package app.fishbuddy.ar.scanner.internal.telemetry

import app.fishbuddy.ar.scanner.ARClassification
import app.fishbuddy.ar.scanner.ARScanMetadata
import org.json.JSONArray
import org.json.JSONObject

/**
 * Builds the JSON document attached to a telemetry-uploaded scan. Pure function
 * over plain data — extracted from TelemetryUploader so it's unit-testable
 * without `android.graphics.Bitmap` (which can't be instantiated in JVM tests).
 *
 * Wire format is documented in `docs/data-safety.md` so customers can paste
 * the field list into their privacy policy.
 *
 *   {
 *     "top":   { "label": "…", "confidence": 0.0 },
 *     "classifications": [{ "label": "…", "confidence": 0.0 }, …],
 *     "measurement_meters": 0.0 | null,
 *     "metadata": { … }   ← omitted when null
 *   }
 */
internal object TelemetryJson {

    fun build(
        topClassification: ARClassification,
        allClassifications: List<ARClassification>,
        measurementMeters: Double?,
        metadata: ARScanMetadata?,
    ): String {
        val root = JSONObject().apply {
            put("top", topClassification.toJson())
            put("classifications", allClassifications.toJsonArray())
            if (measurementMeters != null) {
                put("measurement_meters", measurementMeters)
            }
            if (metadata != null) {
                put("metadata", metadata.toJson())
            }
        }
        return root.toString()
    }

    private fun ARClassification.toJson(): JSONObject = JSONObject().apply {
        put("label", label)
        put("confidence", confidence)
    }

    private fun List<ARClassification>.toJsonArray(): JSONArray = JSONArray().apply {
        this@toJsonArray.forEach { put(it.toJson()) }
    }

    private fun ARScanMetadata.toJson(): JSONObject = JSONObject().apply {
        hashedUserId?.let { put("hashed_user_id", it) }
        coarseLocation?.let {
            put(
                "coarse_location",
                JSONObject().apply {
                    put("latitude", it.latitude)
                    put("longitude", it.longitude)
                },
            )
        }
        weather?.let { w ->
            put(
                "weather",
                JSONObject().apply {
                    w.airTemperatureCelsius?.let { put("air_temperature_celsius", it) }
                    w.windSpeedMetersPerSecond?.let { put("wind_speed_meters_per_second", it) }
                    w.conditionTag?.let { put("condition_tag", it) }
                },
            )
        }
        waterTemperatureCelsius?.let { put("water_temperature_celsius", it) }
        userConfirmedSpecies?.let { put("user_confirmed_species", it) }
        if (custom.isNotEmpty()) {
            put("custom", JSONObject(custom as Map<*, *>))
        }
    }
}
