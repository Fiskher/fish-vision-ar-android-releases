package app.fishbuddy.ar.scanner.internal.license

import java.security.KeyFactory
import java.security.PublicKey
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import java.util.Base64

/**
 * Offline ES256 (P-256 + SHA-256) JWT verifier. No external JWT library —
 * uses only `java.security`. Mirrors iOS SDK's `JWTVerifier` line-for-line.
 *
 * JWT spec encodes the ECDSA signature as raw `R||S` (IEEE P-1363, 64 bytes
 * for P-256), but `java.security.Signature` expects an ASN.1 DER
 * `SEQUENCE { INTEGER R, INTEGER S }`. We convert raw → DER before
 * calling `verify()`.
 */
internal class JWTVerifier(
    publicKeyPEM: String,
    private val expectedAudience: String,
) {
    private val publicKey: PublicKey = parsePEM(publicKeyPEM)

    sealed class VerificationError(message: String) : RuntimeException(message) {
        class Malformed(detail: String) : VerificationError("JWT malformed: $detail")
        object SignatureInvalid :
            VerificationError("JWT signature does not verify against the embedded public key.")
        class Expired(exp: Long, now: Long) :
            VerificationError("JWT expired at $exp (now $now).")
        class AudienceMismatch(expected: String, got: String) :
            VerificationError("JWT aud '$got' != expected '$expected'.")
        class ClaimsDecoding(cause: String) :
            VerificationError("JWT claims could not be decoded: $cause")
    }

    fun verify(
        jwt: String,
        nowEpochSec: Long = System.currentTimeMillis() / 1000,
    ): LicenseJWTClaims {
        val parts = jwt.split(".")
        if (parts.size != 3) {
            throw VerificationError.Malformed("expected 3 dot-separated parts, got ${parts.size}")
        }

        val signingInput = "${parts[0]}.${parts[1]}".toByteArray(Charsets.UTF_8)
        val rawSig = base64UrlDecode(parts[2])
        if (rawSig.size != ES256_SIGNATURE_BYTES) {
            throw VerificationError.Malformed(
                "ES256 signature must be $ES256_SIGNATURE_BYTES bytes (R||S), got ${rawSig.size}",
            )
        }

        val derSig = rawToDer(rawSig)
        val sig = Signature.getInstance("SHA256withECDSA").apply {
            initVerify(publicKey)
            update(signingInput)
        }
        if (!sig.verify(derSig)) throw VerificationError.SignatureInvalid

        val claims = try {
            val payload = String(base64UrlDecode(parts[1]), Charsets.UTF_8)
            LicenseJWTClaims.fromJson(payload)
        } catch (e: Exception) {
            throw VerificationError.ClaimsDecoding(e.toString())
        }

        if (claims.exp < nowEpochSec) throw VerificationError.Expired(claims.exp, nowEpochSec)
        if (claims.aud != expectedAudience) {
            throw VerificationError.AudienceMismatch(expectedAudience, claims.aud)
        }
        return claims
    }

    private fun parsePEM(pem: String): PublicKey {
        val base64 = pem
            .replace("-----BEGIN PUBLIC KEY-----", "")
            .replace("-----END PUBLIC KEY-----", "")
            .replace(Regex("\\s"), "")
        val der = Base64.getDecoder().decode(base64)
        return KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(der))
    }

    private fun base64UrlDecode(s: String): ByteArray {
        // JWT uses unpadded base64url; java's getUrlDecoder requires the
        // padding to be present, so add it back manually.
        val padded = s.padEnd((s.length + 3) / 4 * 4, '=')
        return Base64.getUrlDecoder().decode(padded)
    }

    /** P-1363 R||S (64 bytes) → ASN.1 DER `SEQUENCE { INTEGER R, INTEGER S }`. */
    internal fun rawToDer(raw: ByteArray): ByteArray {
        val half = raw.size / 2
        val rDer = encodeAsn1Integer(raw.copyOfRange(0, half))
        val sDer = encodeAsn1Integer(raw.copyOfRange(half, raw.size))
        val contents = rDer + sDer
        return byteArrayOf(0x30, contents.size.toByte()) + contents
    }

    private fun encodeAsn1Integer(bytes: ByteArray): ByteArray {
        var i = 0
        while (i < bytes.size - 1 && bytes[i] == 0.toByte()) i++
        var stripped = bytes.copyOfRange(i, bytes.size)
        // If the high bit is set, prepend 0x00 so the INTEGER stays positive.
        if ((stripped[0].toInt() and 0x80) != 0) stripped = byteArrayOf(0x00) + stripped
        return byteArrayOf(0x02, stripped.size.toByte()) + stripped
    }

    private companion object {
        const val ES256_SIGNATURE_BYTES = 64
    }
}
