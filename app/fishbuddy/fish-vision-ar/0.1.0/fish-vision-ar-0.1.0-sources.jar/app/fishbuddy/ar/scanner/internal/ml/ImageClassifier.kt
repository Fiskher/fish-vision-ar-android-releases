package app.fishbuddy.ar.scanner.internal.ml

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import app.fishbuddy.ar.scanner.ARClassification
import app.fishbuddy.ar.scanner.ARScannerError
import app.fishbuddy.ar.scanner.internal.ModelPaths
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.ops.NormalizeOp
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.ResizeOp
import org.tensorflow.lite.support.image.ops.Rot90Op
import java.io.IOException

/**
 * Runs the species-classifier TFLite model against a single [Bitmap].
 *
 * The model file lives on disk under `context.filesDir/fishvisionar/models/v1/`.
 * [ARScannerModelLoader.downloadIfNeeded] is responsible for populating it; this
 * class throws [ARScannerError.ModelsNotDownloaded] if the file is missing.
 */
internal class ImageClassifier(
    private val context: Context,
) : AutoCloseable {

    private val labels: List<String> by lazy { Labels.load(context) }

    private val modelBuffer by lazy {
        val source = ModelPaths.resolveClassificationFile(context)
            ?: throw ARScannerError.ModelsNotDownloaded(
                "Classification model not found. Looked in ${ModelPaths.classificationFile(context).absolutePath}, " +
                    "external scoped storage, and assets/fishvisionar/models/v1/. " +
                    "Call ARScannerModelLoader.downloadIfNeeded, push via adb, or bundle in assets.",
            )
        Log.d("ImageClassifier", "loading classification from ${source.displayName}")
        source.mapToBuffer()
    }

    private val interpreter: Interpreter by lazy {
        try {
            Interpreter(modelBuffer)
        } catch (io: IOException) {
            throw ARScannerError.ModelLoad("Failed to load classification model", io)
        }
    }

    private val inputShape: IntArray by lazy { interpreter.getInputTensor(0).shape() }
    private val inputDataType: DataType by lazy { interpreter.getInputTensor(0).dataType() }
    private val normalization by lazy {
        ModelMetadata.readNormalization(modelBuffer, "classification.tflite")
    }

    /**
     * Runs the classifier and returns *all* labels sorted by confidence,
     * descending. Callers are responsible for applying any score threshold.
     *
     * Filtering used to happen here, but that caused the top result to vanish
     * when the model's #1 pick scored below threshold (typical for less common
     * species like brown / sea trout where the classifier is more uncertain),
     * and the UI ended up showing "unknown". Fishbuddy's reference path also
     * returns the full sorted list and trusts the caller — we match that.
     */
    fun classify(
        bitmap: Bitmap,
        orientationDegrees: Int = 0,
    ): List<ARClassification> {
        val inputH = inputShape[1]
        val inputW = inputShape[2]
        val imageProcessor = ImageProcessor.Builder().apply {
            add(ResizeOp(inputH, inputW, ResizeOp.ResizeMethod.BILINEAR))
            normalization?.let { norm ->
                add(NormalizeOp(norm.mean, norm.std))
            }
            if (orientationDegrees != 0) {
                add(Rot90Op(orientationDegrees / 90))
            }
        }.build()

        var tensorImage = TensorImage(inputDataType)
        tensorImage.load(bitmap)
        tensorImage = imageProcessor.process(tensorImage)

        val output = Array(1) { FloatArray(labels.size) }
        Log.d(
            "ImageClassifier",
            "classify: input=${inputShape.toList()} ($inputDataType), labels=${labels.size}",
        )
        interpreter.run(tensorImage.buffer, output)

        return output[0]
            .mapIndexed { i, score ->
                ARClassification(
                    label = labels.getOrElse(i) { "class_$i" },
                    confidence = score.toDouble(),
                )
            }
            .sortedByDescending { it.confidence }
    }

    override fun close() {
        // Lazy-init the interpreter only if the property was touched.
        runCatching { interpreter.close() }
    }
}
