package app.fishbuddy.ar.scanner

/** Snapshot of what's currently cached on disk. */
public enum class ModelStatus {
    /** No models downloaded yet, or the cache directory is empty. */
    NotDownloaded,

    /** All required models present and version-matched. Ready to scan. */
    Downloaded,

    /** Models present but the SDK now expects newer versions; re-download required. */
    NeedsUpdate,
}
