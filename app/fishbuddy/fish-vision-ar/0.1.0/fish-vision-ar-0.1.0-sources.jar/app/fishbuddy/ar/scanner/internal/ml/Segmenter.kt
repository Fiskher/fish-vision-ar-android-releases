package app.fishbuddy.ar.scanner.internal.ml

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import app.fishbuddy.ar.scanner.ARScannerError
import app.fishbuddy.ar.scanner.internal.ModelPaths
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.ops.NormalizeOp
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.ResizeOp
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import java.io.IOException

/**
 * Runs the segmentation TFLite model against a single [Bitmap].
 *
 * Output is a flat `FloatArray` of length `H * W * C` where the model's output
 * tensor shape is `[1, H, W, C]` — caller is responsible for reshaping.
 */
internal class Segmenter(
    private val context: Context,
) : AutoCloseable {

    private val modelBuffer by lazy {
        val source = ModelPaths.resolveSegmentationFile(context)
            ?: throw ARScannerError.ModelsNotDownloaded(
                "Segmentation model not found. Looked in ${ModelPaths.segmentationFile(context).absolutePath}, " +
                    "external scoped storage, and assets/fishvisionar/models/v1/. " +
                    "Call ARScannerModelLoader.downloadIfNeeded, push via adb, or bundle in assets.",
            )
        Log.d(TAG, "loading segmentation from ${source.displayName}")
        source.mapToBuffer()
    }

    private val interpreter: Interpreter by lazy {
        try {
            Interpreter(modelBuffer)
        } catch (io: IOException) {
            throw ARScannerError.ModelLoad("Failed to load segmentation model", io)
        }
    }

    private val normalization by lazy {
        ModelMetadata.readNormalization(modelBuffer, "segmentation.tflite")
    }

    /** Model input width in pixels (queried from the .tflite at load time). */
    val inputWidth: Int by lazy { inputShape[2] }
    /** Model input height in pixels (queried from the .tflite at load time). */
    val inputHeight: Int by lazy { inputShape[1] }
    /** Model output tensor shape, e.g. `[1, H, W]` or `[1, H, W, classes]`. */
    val outputShape: IntArray by lazy { interpreter.getOutputTensor(0).shape() }

    private val inputShape: IntArray by lazy { interpreter.getInputTensor(0).shape() }
    private val inputDataType: DataType by lazy { interpreter.getInputTensor(0).dataType() }

    fun segment(bitmap: Bitmap): FloatArray {
        val imageProcessor = ImageProcessor.Builder()
            .add(ResizeOp(inputHeight, inputWidth, ResizeOp.ResizeMethod.BILINEAR))
            .apply {
                normalization?.let { norm ->
                    add(NormalizeOp(norm.mean, norm.std))
                }
            }
            .build()

        var tensorImage = TensorImage(inputDataType)
        tensorImage.load(bitmap)
        tensorImage = imageProcessor.process(tensorImage)

        val outputTensor = interpreter.getOutputTensor(0)
        val outputBuffer = TensorBuffer.createFixedSize(outputTensor.shape(), DataType.FLOAT32)
        interpreter.run(tensorImage.buffer, outputBuffer.buffer)
        Log.d(
            TAG,
            "segment: input=${inputShape.toList()} ($inputDataType), output=${outputShape.toList()}",
        )
        return outputBuffer.floatArray
    }

    override fun close() {
        runCatching { interpreter.close() }
    }

    private companion object {
        const val TAG = "Segmenter"
    }
}
