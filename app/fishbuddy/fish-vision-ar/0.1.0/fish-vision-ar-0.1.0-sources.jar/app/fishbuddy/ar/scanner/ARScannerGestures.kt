package app.fishbuddy.ar.scanner

/** Gestures the AR surface accepts. */
public enum class ARScannerGestures {
    Tap,
    LongPress,
    All,
    None,
}
