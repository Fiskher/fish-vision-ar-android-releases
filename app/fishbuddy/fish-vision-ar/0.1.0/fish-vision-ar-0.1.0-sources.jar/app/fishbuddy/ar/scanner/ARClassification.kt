package app.fishbuddy.ar.scanner

/**
 * A single species prediction.
 *
 * @param label localised-ready species name (e.g. `"atlantic_cod"`).
 * @param confidence model confidence in `0.0..1.0`.
 */
public data class ARClassification(
    public val label: String,
    public val confidence: Double,
)
