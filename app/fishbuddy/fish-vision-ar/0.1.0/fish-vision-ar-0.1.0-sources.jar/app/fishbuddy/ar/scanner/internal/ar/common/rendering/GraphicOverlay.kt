package app.fishbuddy.ar.scanner.internal.ar.common.rendering

import android.content.Context
import android.graphics.Canvas
import android.graphics.Point
import android.graphics.Rect
import android.graphics.RectF
import android.util.AttributeSet
import android.util.Log
import android.util.SizeF
import android.view.View
import com.google.ar.core.CameraConfig
import java.util.ArrayList

/**
 * A view which renders a series of custom graphics to be overlaid on top of an associated preview
 * (i.e., the camera preview). The creator can add graphics objects, update the objects, and remove
 * them, triggering the appropriate drawing and invalidation within the view.
 *
 *
 * Supports scaling and mirroring of the graphics relative the camera's preview properties. The
 * idea is that detection items are expressed in terms of a preview size, but need to be scaled up
 * to the full view size, and also mirrored in the case of the front-facing camera.
 *
 *
 * Associated [Graphic] items should use [.translateX] and [ ][.translateY] to convert to view coordinate from the preview's coordinate.
 */
internal class GraphicOverlay(context: Context, attrs: AttributeSet) : View(context, attrs) {
    private val lock = Any()

    private var previewWidth: Int = 0
    private var widthScaleFactor = 1.0f
    private var previewHeight: Int = 0
    private var heightScaleFactor = 1.0f
    private val graphics = ArrayList<Graphic>()

    /**
     * Base class for a custom graphics object to be rendered within the graphic overlay. Subclass
     * this and implement the [Graphic.draw] method to define the graphics element. Add
     * instances to the overlay using [GraphicOverlay.add].
     */
    internal abstract class Graphic protected constructor(protected val overlay: GraphicOverlay) {
        protected val context: Context = overlay.context

        /** Draws the graphic on the supplied canvas.  */
        abstract fun draw(canvas: Canvas)
    }

    /** Removes all graphics from the overlay.  */
    fun clear() {
        synchronized(lock) {
            graphics.clear()
        }
        postInvalidate()
    }

    /** Adds a graphic to the overlay.  */
    fun add(graphic: Graphic) {
        synchronized(lock) {
            graphics.add(graphic)
        }
    }

    /**
     * Sets the camera attributes for size and facing direction, which informs how to transform image
     * coordinates later.
     */
    fun setCameraInfo(cameraSource: CameraConfig) {
        Log.d("app_main1", "preview size: " + cameraSource.imageSize.height + "x" + cameraSource.imageSize.width)
        val previewSize = cameraSource.imageSize ?: return
        previewWidth = previewSize.height
        previewHeight = previewSize.width

//        if (cameraSource.facingDirection == CameraConfig.FacingDirection.BACK) {
//            // Swap width and height when in portrait, since camera's natural orientation is landscape.
//            previewWidth = previewSize.height
//            previewHeight = previewSize.width
//        } else {
//            previewWidth = previewSize.width
//            previewHeight = previewSize.height
//        }
    }

    fun setCameraInfo(cameraSource: SizeF?) {
        Log.d(
            "app_main1",
            "preview size: " + cameraSource?.height + "x" + cameraSource?.width
        )
        val previewSize = cameraSource ?: return
        previewWidth = 1440
        previewHeight = 2864

    }

    fun translateX(x: Float): Float = x * widthScaleFactor
    fun translateY(y: Float): Float = y * heightScaleFactor

    /**
     * Adjusts the `rect`'s coordinate from the preview's coordinate system to the view
     * coordinate system.
     */
    fun translateRect(rect: Rect) = RectF(
            translateX(rect.left.toFloat()),
            translateY(rect.top.toFloat()),
            translateX(rect.right.toFloat()),
            translateY(rect.bottom.toFloat())
    )

    /**
     * Adjusts the coordinates from the preview's coordinate system to the view
     * coordinate system.
     */
    fun translateCenterPoint(centerCoordinates: Pair<Int, Int>) = Pair<Int, Int>(translateX(centerCoordinates.first.toFloat()).toInt(), translateY(centerCoordinates.second.toFloat()).toInt())

    /** Draws the overlay with its associated graphic objects.  */
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (previewWidth == 0 && previewHeight == 0) {
            return
        }

        if (previewWidth > 0 && previewHeight > 0) {
            widthScaleFactor = width.toFloat() / previewWidth
            heightScaleFactor = height.toFloat() / previewHeight

        }
        Log.d("app_main1", "height scale factor: " + heightScaleFactor + ", width scale factor: " + widthScaleFactor + ", view widht: " + width + ", view height: " + height + ", preview widht: " + previewWidth + ", preview height: " + previewHeight)

        synchronized(lock) {
            graphics.forEach { it.draw(canvas) }
        }
    }

}
