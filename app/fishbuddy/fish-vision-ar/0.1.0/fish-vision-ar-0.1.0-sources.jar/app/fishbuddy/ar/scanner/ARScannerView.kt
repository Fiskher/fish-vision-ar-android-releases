package app.fishbuddy.ar.scanner

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import app.fishbuddy.ar.scanner.internal.view.ARScannerViewController

/**
 * The on-device AR fish scanner.
 *
 * Hosts an ARCore camera session, runs on-device classification, and surfaces every
 * completed scan through [onScan]. Drive the session imperatively via [controller];
 * observe its lifecycle via [ARScannerController.state].
 *
 * Lifecycle: this composable installs a lifecycle observer so that ARCore session
 * resume/pause/close align with the host lifecycle.
 *
 * @param controller the session controller; create once per screen and survive
 *   configuration changes (e.g. hoist into a `ViewModel`).
 * @param configuration scanner settings — license is required, everything else has
 *   a sensible default.
 * @param onScan invoked once per completed scan, on the calling coroutine context.
 * @param modifier applied to the root surface that hosts the AR camera.
 */
@Composable
public fun ARScannerView(
    controller: ARScannerController,
    configuration: ARScannerConfiguration,
    onScan: suspend (ARScanOutcome) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    val viewController = remember(controller, configuration) {
        ARScannerViewController(
            context = context,
            configuration = configuration,
            controller = controller,
            scope = scope,
            onScan = onScan,
        )
    }

    DisposableEffect(lifecycleOwner, viewController) {
        val activity = context.findActivity()
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> viewController.onResume(activity)
                Lifecycle.Event.ON_PAUSE -> viewController.onPause()
                Lifecycle.Event.ON_DESTROY -> viewController.onDestroy()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            viewController.onDestroy()
        }
    }

    AndroidView(
        modifier = modifier,
        factory = { viewController.view },
    )
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
