package app.fishbuddy.ar.scanner

import android.graphics.Bitmap

/**
 * Result of a completed scan.
 *
 * @param image the captured frame, owned by the consumer (recycle when done).
 * @param topClassification highest-confidence species prediction.
 * @param allClassifications full list of predictions above
 *   [ARScannerConfiguration.scoreThreshold], descending by confidence.
 * @param measurementMeters length in metres, or `null` if measurement was skipped
 *   or failed (e.g. user only tapped one anchor, or AR tracking was lost).
 * @param measurementUncertaintyMeters one standard deviation around
 *   [measurementMeters], or `null` when the measurement came from a single
 *   observation and carries no spread. Where present it describes **depth and
 *   pose noise only** — the segmentation endpoints are fixed once per scan, so
 *   it says nothing about how well the fish was outlined. Treat a large band as
 *   a signal to re-scan rather than as a tolerance to quote.
 * @param measurementSampleCount how many observations the measurement was
 *   aggregated from. 1 means single-frame.
 * @param measurementIsCoarse `true` when the measurement rests on an estimated
 *   rather than a tracked position. Manual two-anchor measurements land via
 *   ARCore Instant Placement, whose pose starts at a fixed approximate distance
 *   and is only corrected once ARCore has enough parallax to refine it. A scan
 *   taken before that refinement scales with the guess, so the number can be
 *   confidently wrong. Treat a coarse measurement as an estimate: fine for a
 *   catch log, not something to quote as a measured length.
 */
public data class ARScanOutcome(
    public val image: Bitmap,
    public val topClassification: ARClassification,
    public val allClassifications: List<ARClassification>,
    public val measurementMeters: Double?,
    public val measurementUncertaintyMeters: Double? = null,
    public val measurementSampleCount: Int = 1,
    public val measurementIsCoarse: Boolean = false,
)
