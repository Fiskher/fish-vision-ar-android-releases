package app.fishbuddy.ar.scanner

/** Errors surfaced by the scanner. All are subtypes of [Exception]. */
public sealed class ARScannerError(
    message: String,
    cause: Throwable? = null,
) : Exception(message, cause) {

    /** License missing, expired, revoked, or wrong package name. */
    public class LicenseInvalid(message: String) : ARScannerError(message)

    /** TFLite model failed to load — corrupt, or unsupported by the runtime. */
    public class ModelLoad(message: String, cause: Throwable? = null) :
        ARScannerError(message, cause)

    /**
     * Models aren't on disk yet. Caller must invoke
     * [ARScannerModelLoader.downloadIfNeeded] before the first scan.
     */
    public class ModelsNotDownloaded(message: String) : ARScannerError(message)

    /** Model download failed at the network or disk layer. */
    public class ModelDownload(message: String, cause: Throwable? = null) :
        ARScannerError(message, cause)

    /** ARCore not installed, declined by user, or device incompatible. */
    public class ArCoreUnavailable(message: String) : ARScannerError(message)

    /** Camera access denied or hardware unavailable. */
    public class CameraUnavailable(message: String) : ARScannerError(message)
}
