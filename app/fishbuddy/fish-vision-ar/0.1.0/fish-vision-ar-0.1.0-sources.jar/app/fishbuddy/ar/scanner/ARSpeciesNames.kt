package app.fishbuddy.ar.scanner

import android.content.Context
import android.util.Log
import org.json.JSONObject
import java.util.Locale

/**
 * Translates the latin species name in [ARClassification.label] into a name to
 * show a user.
 *
 * [ARClassification.label] stays latin on purpose: it is the model's stable
 * identifier, it matches `labels.txt`, and it is what you should persist, log
 * and compare against. This is the display layer on top of it — call it at the
 * point you render a name, not when you store one.
 *
 * Resolution order, per name:
 *  1. the device language (e.g. `nb` for Norwegian Bokmål)
 *  2. English
 *  3. the latin name unchanged
 *
 * The last step means an unknown or untranslated species always renders as
 * *something* readable rather than blank.
 *
 * ### Coverage
 *
 * The bundled catalogue does **not** cover all 205 species the classifier can
 * return — the rest fall through to latin. If your app already has a species
 * catalogue (Fishbuddy resolves `Species.localizedName` from its backend), you
 * are better off mapping [ARClassification.label] through that and ignoring this
 * helper; it exists so integrators without one aren't forced to show latin.
 *
 * ### Adding names
 *
 * Supply [extraNames] to override or extend the bundled catalogue at runtime —
 * entries there win over the bundled ones. Keys must be exactly as they appear
 * in `labels.txt`, including capitalisation.
 */
public object ARSpeciesNames {

    private const val TAG = "ARSpeciesNames"
    private const val ASSET_DIR = "fishvisionar/species_names"
    private const val FALLBACK_LANGUAGE = "en"

    @Volatile
    private var cache: Map<String, Map<String, String>> = emptyMap()

    /**
     * @param latinName a value from [ARClassification.label].
     * @param locale which language to resolve in; defaults to the device locale.
     * @param extraNames caller-supplied names that win over the bundled catalogue.
     * @return the localized name, or [latinName] if there is no translation.
     */
    @JvmOverloads
    public fun localize(
        context: Context,
        latinName: String,
        locale: Locale = Locale.getDefault(),
        extraNames: Map<String, String> = emptyMap(),
    ): String {
        if (latinName.isBlank()) return latinName
        extraNames[latinName]?.let { return it }
        val appContext = context.applicationContext
        catalogFor(appContext, locale.language)[latinName]?.let { return it }
        if (locale.language != FALLBACK_LANGUAGE) {
            catalogFor(appContext, FALLBACK_LANGUAGE)[latinName]?.let { return it }
        }
        return latinName
    }

    /**
     * How many of [labels] the bundled catalogue can translate in [locale].
     * Useful in a debug build to see how much of the model's output would render
     * as latin.
     */
    public fun coverage(context: Context, labels: List<String>, locale: Locale = Locale.getDefault()): Int {
        val catalog = catalogFor(context.applicationContext, locale.language)
        val fallback = catalogFor(context.applicationContext, FALLBACK_LANGUAGE)
        return labels.count { it in catalog || it in fallback }
    }

    private fun catalogFor(context: Context, language: String): Map<String, String> {
        cache[language]?.let { return it }
        val loaded = loadCatalog(context, language)
        synchronized(this) { cache = cache + (language to loaded) }
        return loaded
    }

    private fun loadCatalog(context: Context, language: String): Map<String, String> = try {
        context.assets.open("$ASSET_DIR/$language.json").use { stream ->
            parseCatalog(stream.readBytes().toString(Charsets.UTF_8))
        }
    } catch (t: Throwable) {
        // A missing language file is the normal case, not an error.
        Log.d(TAG, "no species catalogue for '$language': ${t.message}")
        emptyMap()
    }

    /** Split out from IO so the parsing and fallback rules can be unit-tested. */
    internal fun parseCatalog(json: String): Map<String, String> = try {
        val obj = JSONObject(json)
        buildMap {
            obj.keys().forEach { key ->
                val value = obj.optString(key)
                if (value.isNotBlank()) put(key, value)
            }
        }
    } catch (t: Throwable) {
        Log.w(TAG, "malformed species catalogue: ${t.message}")
        emptyMap()
    }
}
