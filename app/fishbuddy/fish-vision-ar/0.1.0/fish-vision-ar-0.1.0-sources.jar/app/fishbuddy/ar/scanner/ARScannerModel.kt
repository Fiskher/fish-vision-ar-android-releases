package app.fishbuddy.ar.scanner

/** Which on-device model the scanner runs. */
public enum class ARScannerModel {
    /** Faster, smaller — classification only. */
    SpeciesClassifier,

    /** Segmentation + classification. Required for length measurement. */
    Segmentation,
}
