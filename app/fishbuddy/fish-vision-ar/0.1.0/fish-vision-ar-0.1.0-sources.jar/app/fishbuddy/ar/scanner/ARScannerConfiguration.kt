package app.fishbuddy.ar.scanner

/**
 * Scanner configuration. All fields except [license] have sensible defaults that
 * match the in-app behaviour of Fishbuddy.
 *
 * @param license customer license key — required.
 * @param dataContribution telemetry opt-in. Defaults to [ARScannerDataContribution.Disabled].
 * @param scoreThreshold minimum classification confidence (0.0–1.0) for a result
 *   to be surfaced.
 * @param measurementNodeCount how many AR anchors the user places to measure
 *   length. Default 2 (head + tail).
 * @param showsArCoreInstallPrompt when true, the SDK triggers ARCore install if
 *   not present. Set false to handle the flow in the host app.
 * @param enabledGestures which gestures the AR surface accepts.
 * @param modelVariant which on-device model the scanner runs.
 * @param licenseBackendURL base URL for license validation. Defaults to the
 *   production endpoint; override only for local development (e.g.
 *   `"http://10.0.2.2:8080"` against an emulator-loopback backend).
 * @param modelBaseURL base URL the TFLite models are downloaded from by
 *   [ARScannerModelLoader.downloadIfNeeded]. Defaults to the public GitHub
 *   Release assets for tag `models-v1`. Must end in `/` — the model file name
 *   is appended directly. Override to serve the models from your own origin
 *   (e.g. an air-gapped mirror, or a license-gated proxy).
 */
public data class ARScannerConfiguration(
    public val license: ARScannerLicense,
    public val dataContribution: ARScannerDataContribution = ARScannerDataContribution.Disabled,
    public val scoreThreshold: Float = DEFAULT_SCORE_THRESHOLD,
    public val measurementNodeCount: Int = DEFAULT_MEASUREMENT_NODE_COUNT,
    public val showsArCoreInstallPrompt: Boolean = true,
    public val enabledGestures: ARScannerGestures = ARScannerGestures.All,
    public val modelVariant: ARScannerModel = ARScannerModel.SpeciesClassifier,
    public val licenseBackendURL: String = DEFAULT_LICENSE_BACKEND_URL,
    public val modelBaseURL: String = DEFAULT_MODEL_BASE_URL,
) {
    public companion object {
        public const val DEFAULT_SCORE_THRESHOLD: Float = 0.5f
        public const val DEFAULT_MEASUREMENT_NODE_COUNT: Int = 2
        public const val DEFAULT_LICENSE_BACKEND_URL: String = "https://sdk.fiskher.no"

        /**
         * Public GitHub Release assets for the `models-v1` tag. Downloads are not
         * credential-gated — access control is the runtime license check every
         * `captureAndScan()` performs against [DEFAULT_LICENSE_BACKEND_URL].
         *
         * Model updates ship as a new tag (`models-v2`) and a new default here;
         * bytes already published under an asset name are never rewritten.
         */
        public const val DEFAULT_MODEL_BASE_URL: String =
            "https://github.com/Fiskher/fish-vision-ar-android-releases/releases/download/models-v1/"
    }
}
