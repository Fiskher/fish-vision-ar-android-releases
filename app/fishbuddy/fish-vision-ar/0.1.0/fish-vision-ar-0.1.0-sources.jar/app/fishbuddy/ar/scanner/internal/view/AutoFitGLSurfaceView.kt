package app.fishbuddy.ar.scanner.internal.view

import android.content.Context
import android.opengl.GLSurfaceView
import android.util.AttributeSet
import android.view.View

internal class AutoFitGLSurfaceView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : GLSurfaceView(context, attrs) {

    private var ratioW = 0
    private var ratioH = 0
    var verticalBias = 0.4f

    fun setAspectRatio(w: Int, h: Int) {
        require(w > 0 && h > 0)
        ratioW = w; ratioH = h
        requestLayout()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        if (ratioW == 0 || ratioH == 0) {
            setMeasuredDimension(w, h)
        } else {
            if (w < h * ratioW / ratioH) {
                setMeasuredDimension(w, w * ratioH / ratioW)
            } else {
                setMeasuredDimension(h * ratioW / ratioH, h)
            }
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        val parentH = (parent as? View)?.height ?: return
        val surfaceH = height
        translationY = ((parentH - surfaceH).coerceAtLeast(0) * verticalBias)
    }
}
