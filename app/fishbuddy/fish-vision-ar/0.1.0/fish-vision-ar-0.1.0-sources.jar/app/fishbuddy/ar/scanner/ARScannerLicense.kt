package app.fishbuddy.ar.scanner

/**
 * Customer license key issued by the FishVisionAR backend.
 *
 * Wraps the raw string so that future versions can carry signed envelopes,
 * expiry hints, or tenant routing without breaking the public API.
 */
public data class ARScannerLicense(public val key: String)
