package app.fishbuddy.ar.scanner.internal.ar.rawdepth

/**
 * Layout constants for raw-depth point buffers, kept separate from the full
 * `DepthData` scene-pipeline implementation that the iOS reference port carries.
 * The SDK only needs the two-endpoint measurement (see [DepthMeasurer]) plus
 * these tiny structural constants used by the depth-cloud renderers.
 */
internal object DepthConstants {
    /** Each depth point packs: world X, Y, Z, confidence in [0, 1]. */
    const val FLOATS_PER_POINT: Int = 4
}
