package app.fishbuddy.ar.scanner.internal.license

import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resumeWithException

/**
 * Thin OkHttp wrapper around `POST /v1/license/validate`. Surfaces 403 explicitly
 * (license invalid / unknown / wrong bundleId) so the caller can map to
 * `ARScannerError.LicenseInvalid`; everything else is `Transport` or
 * `UnexpectedStatus`.
 */
internal class LicenseHTTPClient(
    private val baseURL: String,
    private val okHttp: OkHttpClient = defaultOkHttp(),
) {

    sealed class HTTPError(message: String) : RuntimeException(message) {
        class Forbidden(val body: String) : HTTPError("Backend rejected license (403): $body")
        class UnexpectedStatus(val code: Int, val body: String) :
            HTTPError("Backend returned HTTP $code: $body")
        class Transport(cause: Throwable) :
            HTTPError("Network error contacting license backend: $cause")
        class DecodingFailed(val detail: String) :
            HTTPError("Backend response could not be decoded: $detail")
    }

    suspend fun validate(req: LicenseValidateRequest): LicenseValidateResponse {
        val url = "${baseURL.trimEnd('/')}/v1/license/validate"
        val body = req.toJson().toRequestBody(JSON_MEDIA_TYPE)
        val httpReq = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .post(body)
            .build()

        val resp = try {
            okHttp.newCall(httpReq).await()
        } catch (e: IOException) {
            throw HTTPError.Transport(e)
        }

        return resp.use { response ->
            val respBody = response.body?.string().orEmpty()
            when (response.code) {
                200 -> try {
                    LicenseValidateResponse.fromJson(respBody)
                } catch (e: Exception) {
                    throw HTTPError.DecodingFailed("body=$respBody error=$e")
                }
                403 -> throw HTTPError.Forbidden(respBody)
                else -> throw HTTPError.UnexpectedStatus(response.code, respBody)
            }
        }
    }

    private companion object {
        val JSON_MEDIA_TYPE = "application/json".toMediaType()

        fun defaultOkHttp(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }
}

/** Bridge OkHttp's callback API into coroutines. */
private suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
    enqueue(object : Callback {
        override fun onResponse(call: Call, response: Response) =
            cont.resumeWith(Result.success(response))

        override fun onFailure(call: Call, e: IOException) =
            cont.resumeWithException(e)
    })
    cont.invokeOnCancellation { runCatching { cancel() } }
}
