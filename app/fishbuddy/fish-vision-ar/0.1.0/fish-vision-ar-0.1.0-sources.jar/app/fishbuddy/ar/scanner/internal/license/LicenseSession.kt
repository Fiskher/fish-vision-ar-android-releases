package app.fishbuddy.ar.scanner.internal.license

import android.content.Context
import java.security.MessageDigest
import java.time.Instant

/**
 * Orchestrates license validation. Mirrors iOS SDK 0.1.1 — including the
 * license-key-keyed cache fix: the cache stores SHA-256(licenseKey) so a
 * rotated license key invalidates the previously-cached JWT instead of
 * serving stale credentials.
 *
 * Cache hit path is purely local: SharedPreferences read + JWT verify
 * against the embedded public key. Misses, expiries, and key-rotation
 * mismatches all fall through to a fresh `/v1/license/validate` call.
 */
internal class LicenseSession(
    private val context: Context,
    private val licenseKey: String,
    backendURL: String,
    private val bundleId: String,
    private val httpClient: LicenseHTTPClient = LicenseHTTPClient(backendURL),
    private val verifier: JWTVerifier = JWTVerifier(EmbeddedPublicKey.PEM, bundleId),
) {

    sealed class SessionError(message: String, cause: Throwable? = null) :
        RuntimeException(message, cause) {
        object NoLicenseKey : SessionError("License key is empty.")
        class ValidationFailed(cause: Throwable) :
            SessionError("License validation failed: $cause", cause)
        class VerificationFailed(cause: Throwable) :
            SessionError("Cached license JWT is invalid: $cause", cause)
    }

    /**
     * Returns a verified, non-expired JWT. Refreshes from the backend if the
     * cache is empty, expired, or was stored for a different license key.
     * Throws on network failure or verification failure.
     */
    suspend fun ensureValidJWT(): String {
        if (licenseKey.isEmpty()) throw SessionError.NoLicenseKey

        loadCachedJWT()?.let { cached ->
            try {
                verifier.verify(cached)
                return cached
            } catch (_: Throwable) {
                // Cache miss; fall through to a fresh validate.
            }
        }

        val req = LicenseValidateRequest(
            licenseKey = licenseKey,
            bundleId = bundleId,
            deviceHash = DeviceHash.value(context),
        )

        val resp = try {
            httpClient.validate(req)
        } catch (e: Throwable) {
            throw SessionError.ValidationFailed(e)
        }

        try {
            verifier.verify(resp.jwt)
        } catch (e: Throwable) {
            throw SessionError.VerificationFailed(e)
        }

        val expiresEpochSec = try {
            Instant.parse(resp.expiresAt).epochSecond
        } catch (_: Throwable) {
            // The backend's contract puts authoritative expiry in the JWT itself;
            // a malformed `expiresAt` string just means we can't pre-empt that
            // value from the cache. Fall back to "don't cache an expiry."
            0L
        }
        storeCachedJWT(resp.jwt, expiresEpochSec)
        return resp.jwt
    }

    private fun loadCachedJWT(): String? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val jwt = prefs.getString(KEY_JWT, null) ?: return null
        if (jwt.isEmpty()) return null

        val expiry = prefs.getLong(KEY_EXPIRY, 0L)
        if (expiry <= 0L || expiry <= System.currentTimeMillis() / 1000) return null

        // Tie the cache to the current license-key value. If the host app
        // rotated the key, the previously-cached JWT — though still
        // cryptographically valid for the OLD key — is not the right
        // credential to present. Force a re-validate.
        val storedHash = prefs.getString(KEY_HASH, null) ?: return null
        if (storedHash != hashLicenseKey(licenseKey)) return null

        return jwt
    }

    private fun storeCachedJWT(jwt: String, expiresEpochSec: Long) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_JWT, jwt)
            .putLong(KEY_EXPIRY, expiresEpochSec)
            .putString(KEY_HASH, hashLicenseKey(licenseKey))
            .apply()
    }

    internal companion object {
        // Shared with DeviceHash on purpose — one SharedPreferences file for all
        // license-related state keeps the on-device footprint trivial.
        private const val PREFS = DeviceHash.PREFS
        private const val KEY_JWT = "cachedJWT"
        private const val KEY_EXPIRY = "cachedJWTExpiresAt"
        private const val KEY_HASH = "cachedJWTLicenseKeyHash"

        fun hashLicenseKey(key: String): String =
            MessageDigest.getInstance("SHA-256")
                .digest(key.toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
    }
}
