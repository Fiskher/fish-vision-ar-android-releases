package app.fishbuddy.ar.scanner.internal

/**
 * Flags for the ported scanner-accuracy fixes.
 *
 * Mirrors the flag-per-phase discipline in `fishbuddy_android`'s
 * `docs/scanner-accuracy-improvements.md`: never modify a working measurement
 * path inline — add the new path behind its flag, verify it on-device against
 * the Phase 0 harness, then make it permanent and delete the flag.
 *
 * These are `@Volatile var` rather than `const val` because the SDK ships as a
 * binary AAR: a device test can toggle a path without rebuilding the library.
 */
internal object ScanFlags {

    /**
     * D3 — refuse a depth measurement when either endpoint has no usable depth,
     * instead of "recovering" it.
     *
     * The pre-fix path copied the good endpoint's confidence and depth scalar
     * over the bad one's, but not its 3-D world coordinates — and only the world
     * coordinates feed the distance. An endpoint with zero depth therefore
     * unprojects to the camera origin, and the returned figure is the
     * camera-to-fish distance rather than head-to-tail. At a typical 0.3–1.0 m
     * scan range that lands inside the plausible fish-length band and passes the
     * 2 m sanity cap, so it surfaces as a confident, ordinary-looking, wrong
     * measurement.
     *
     * **Defaults on.** Both branches can fail to produce a length, but only the
     * old one can produce a wrong length, and refusing to measure is the safer
     * failure for a result that may be quoted to a regulator. The cost is that
     * scans with one occluded endpoint now return `null` instead of a number.
     * Set false to restore the previous behaviour for an A/B against the
     * Phase 0 logs.
     */
    @Volatile
    var depthMeasureFixesEnabled: Boolean = true

    /**
     * D4 — sample a patch of depth pixels per endpoint and take the median,
     * instead of trusting a single pixel.
     *
     * The pre-fix path read one depth pixel per endpoint and, although it
     * computed that pixel's confidence, only ever used it for a zero test. Raw
     * depth is noisy at object boundaries — which is exactly where a fish's snout
     * and tail are — so a single sample can be metres out with no indication.
     *
     * The new path samples a [DEPTH_PATCH_RADIUS]-radius window, discards samples
     * below [DEPTH_CONFIDENCE_THRESHOLD] or with zero depth, and takes the median
     * of what survives. Fewer than [MIN_CONFIDENT_DEPTH_SAMPLES] survivors means
     * the endpoint isn't measurable and the scan is refused rather than guessed.
     *
     * **Defaults on**, on the same reasoning as [depthMeasureFixesEnabled]: the
     * failure mode it introduces is refusing to measure, not measuring wrongly.
     */
    @Volatile
    var depthPatchSamplingEnabled: Boolean = true

    /** Half-width of the depth sampling window: 2 gives a 5x5 patch, as on master. */
    const val DEPTH_PATCH_RADIUS: Int = 2

    /** Confidence gate for a usable depth sample, matching master's Phase 3. */
    const val DEPTH_CONFIDENCE_THRESHOLD: Float = 0.9f

    /** Below this many confident samples in the patch, the endpoint is unusable. */
    const val MIN_CONFIDENT_DEPTH_SAMPLES: Int = 3

    /**
     * D5 — take endpoints along the fish's own principal axis rather than along
     * whichever image axis happens to be longer.
     *
     * The pre-fix path chose the image axis (horizontal or vertical) carrying the
     * longer silhouette, then took the centre-line extremes along it. A fish held
     * diagonally is measured along its projection onto that axis, so it reads
     * short: a fish at 45 degrees loses about a third of its length, and the
     * reading changes as the user rotates the phone.
     *
     * The new path runs a 2x2 PCA over the largest connected mask component and
     * takes the pixels at the extreme projections onto the major axis. Endpoints
     * stay on the mask, which matters because they are also where depth gets
     * sampled — an endpoint off the silhouette would read background depth.
     *
     * **Defaults on.** Unlike D3 and D4 this one changes a number rather than
     * introducing a refusal, so it is the ported fix most in need of on-device
     * A/B against the Phase 0 logs before 0.1.0 ships.
     */
    @Volatile
    var endpointPcaEnabled: Boolean = true

    /**
     * D6 — aggregate the measurement over several frames and report a median plus
     * a one-sigma band, instead of trusting one frame.
     *
     * Segmentation runs **once**, on the armed frame, fixing the endpoints. The
     * following frames re-sample depth at those same endpoints and re-unproject
     * with each frame's pose, so there is no repeat ML cost. Samples are combined
     * by [app.fishbuddy.ar.scanner.internal.ml.TemporalAggregator]. Because the
     * endpoints are fixed, the resulting band describes depth and pose noise, not
     * segmentation variance.
     *
     * **Defaults off**, unlike D3/D4/D5. This one changes the shape of the
     * capture flow — the outcome is emitted several frames after the shutter
     * rather than during it — and that interacts with the deliberate ~1-2 s view
     * freeze during inference. It has never run on a device. Turn it on for the
     * calibration session, confirm against `temporal.csv` that sigma tracks the
     * observed frame-to-frame spread, then make it the default.
     */
    @Volatile
    var scanTemporalAggregationEnabled: Boolean = false

    /** Samples to collect before finalising an aggregated measurement. */
    const val TEMPORAL_TARGET_SAMPLES: Int = 8

    /**
     * Frames to spend trying to reach [TEMPORAL_TARGET_SAMPLES] before finalising
     * with whatever has been collected. Keeps aggregation well inside the
     * scan watchdog even when most frames fail to yield a usable depth sample.
     */
    const val TEMPORAL_FRAME_BUDGET: Int = 12
}
