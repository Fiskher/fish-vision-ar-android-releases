package app.fishbuddy.ar.scanner.internal.telemetry

import android.graphics.Bitmap
import android.util.Log
import app.fishbuddy.ar.scanner.ARScanMetadata
import app.fishbuddy.ar.scanner.ARScanOutcome
import app.fishbuddy.ar.scanner.ARScannerLicense
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Uploads a completed scan to the FishVisionAR telemetry endpoint when the
 * consumer has opted in via `ARScannerDataContribution.Enabled`. Multipart POST
 * of `{ image: scan.jpg, metadata: scan.json }`, Bearer-auth'd with the license
 * key (transitions to a real license JWT when backend Phase B1 ships).
 *
 * Fire-and-forget on `Dispatchers.IO` — never blocks the scanner UI. Failures
 * are logged at WARN; an upload failure does not surface to the consumer's
 * `onScan` callback.
 */
internal class TelemetryUploader(
    private val baseUrl: String = DEFAULT_BASE_URL,
    private val client: OkHttpClient = defaultClient(),
) {

    suspend fun upload(
        outcome: ARScanOutcome,
        metadata: ARScanMetadata?,
        license: ARScannerLicense,
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val jpeg = compressJpeg(outcome.image)
            val metadataJson = TelemetryJson.build(
                topClassification = outcome.topClassification,
                allClassifications = outcome.allClassifications,
                measurementMeters = outcome.measurementMeters,
                metadata = metadata,
            )
            val body = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart(
                    name = "image",
                    filename = "scan.jpg",
                    body = jpeg.toRequestBody(JPEG_MEDIA_TYPE),
                )
                .addFormDataPart(
                    name = "metadata",
                    filename = "scan.json",
                    body = metadataJson.toRequestBody(JSON_MEDIA_TYPE),
                )
                .build()

            val request = Request.Builder()
                .url("$baseUrl$SCANS_PATH")
                .header("Authorization", "Bearer ${license.key}")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("Telemetry HTTP ${response.code}: ${response.message}")
                }
                Log.d(TAG, "scan uploaded: ${jpeg.size}B image + ${metadataJson.length}B metadata")
            }
            Unit
        }.onFailure { Log.w(TAG, "telemetry upload failed", it) }
    }

    private fun compressJpeg(bitmap: Bitmap, quality: Int = JPEG_QUALITY): ByteArray {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, stream)
        return stream.toByteArray()
    }

    companion object {
        // Production endpoint. Same host as the Maven + model-download paths;
        // the Worker routes /v1/* to the backend rather than to R2.
        const val DEFAULT_BASE_URL = "https://dl.fishbuddy.app"
        private const val SCANS_PATH = "/v1/scans"
        private const val JPEG_QUALITY = 85
        private const val TAG = "TelemetryUploader"

        private val JPEG_MEDIA_TYPE = "image/jpeg".toMediaType()
        private val JSON_MEDIA_TYPE = "application/json".toMediaType()

        private fun defaultClient(): OkHttpClient = OkHttpClient.Builder()
            .callTimeout(45, TimeUnit.SECONDS)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
    }
}
