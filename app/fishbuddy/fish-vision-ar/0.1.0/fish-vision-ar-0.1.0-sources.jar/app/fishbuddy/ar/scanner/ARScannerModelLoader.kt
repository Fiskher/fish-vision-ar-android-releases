package app.fishbuddy.ar.scanner

import android.content.Context
import android.util.Base64
import android.util.Log
import app.fishbuddy.ar.scanner.internal.ModelPaths
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.OkHttpClient
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Request
import okio.buffer
import okio.sink
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Downloads and caches the on-device ML models the scanner depends on.
 *
 * The first scan needs roughly 225 MB of model data on disk. Customers should call
 * [downloadIfNeeded] from a screen that can surface a progress bar — typically a
 * one-time onboarding step — well before the user opens the AR camera view.
 *
 * Cached files live in `context.filesDir/fishvisionar/models/v1/` and survive app
 * upgrades. Use [deleteCachedModels] to clear them (e.g. for a "free up space"
 * setting). Use [recoverCorruptCache] to automatically re-download when a cached
 * model file is unreadable or partial — drops the cached copy and re-runs
 * [downloadIfNeeded] once per process per call site.
 */
public class ARScannerModelLoader {

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .callTimeout(0, TimeUnit.MILLISECONDS) // model download can be slow on cell
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    @JvmOverloads
    public fun downloadIfNeeded(
        context: Context,
        license: ARScannerLicense,
        modelBaseURL: String = ARScannerConfiguration.DEFAULT_MODEL_BASE_URL,
    ): Flow<ModelDownloadState> = flow {
        emit(ModelDownloadState.CheckingCache)
        val appCtx = context.applicationContext

        // Honour the external-storage dev fallback too: if both files are present in
        // EITHER location, treat the cache as warm and skip the network entirely.
        if (ModelPaths.resolveClassificationFile(appCtx) != null &&
            ModelPaths.resolveSegmentationFile(appCtx) != null
        ) {
            emit(ModelDownloadState.Completed)
            return@flow
        }
        val classFile = ModelPaths.classificationFile(appCtx)
        val segFile = ModelPaths.segmentationFile(appCtx)

        ModelPaths.modelsDir(appCtx).mkdirs()
        try {
            if (!ModelPaths.isPresent(classFile)) {
                emitAll(
                    downloadOne(
                        baseUrl = modelBaseURL,
                        urlPath = ModelPaths.CLASSIFICATION_FILE_NAME,
                        target = classFile,
                        license = license,
                    ),
                )
            }
            if (!ModelPaths.isPresent(segFile)) {
                emitAll(
                    downloadOne(
                        baseUrl = modelBaseURL,
                        urlPath = ModelPaths.SEGMENTATION_FILE_NAME,
                        target = segFile,
                        license = license,
                    ),
                )
            }
            emit(ModelDownloadState.Completed)
        } catch (io: IOException) {
            emit(
                ModelDownloadState.Failed(
                    ARScannerError.ModelDownload(
                        "Failed to download ${io.message ?: "model"}",
                        io,
                    ),
                ),
            )
        }
    }.flowOn(Dispatchers.IO)

    public fun status(context: Context): ModelStatus {
        val appCtx = context.applicationContext
        val classOk = ModelPaths.resolveClassificationFile(appCtx) != null
        val segOk = ModelPaths.resolveSegmentationFile(appCtx) != null
        return if (classOk && segOk) ModelStatus.Downloaded else ModelStatus.NotDownloaded
        // ModelStatus.NeedsUpdate is reserved for future use when we ship a version
        // file alongside the models and bump it in-SDK.
    }

    public fun deleteCachedModels(context: Context) {
        val dir = ModelPaths.modelsDir(context.applicationContext)
        if (dir.exists()) dir.deleteRecursively()
    }

    /**
     * Recover from a corrupt or partial cached model. Deletes the **internal-
     * storage** copies of the model files (external-storage and bundled-asset
     * fallbacks are left alone) and re-runs [downloadIfNeeded]. Throttled to
     * [MAX_RECOVERY_ATTEMPTS_PER_PROCESS] attempts per process so a broken
     * download source can't put the app in a re-download loop.
     *
     * Call this when the scanner surfaces [ARScannerError.ModelLoad] — the
     * cached `.tflite` is unreadable to the TFLite interpreter. Common cause:
     * an interrupted download or filesystem corruption. The recovered flow
     * emits the same [ModelDownloadState] sequence as a fresh
     * [downloadIfNeeded] call.
     *
     * Mirrors the role of `MLModel.recoverBrokenMLModule` in the original
     * Fishbuddy DFM flow — same recover-once-per-process semantics, different
     * delivery mechanism.
     */
    @JvmOverloads
    public fun recoverCorruptCache(
        context: Context,
        license: ARScannerLicense,
        modelBaseURL: String = ARScannerConfiguration.DEFAULT_MODEL_BASE_URL,
    ): Flow<ModelDownloadState> = flow {
        val attempt = recoveryAttempts.incrementAndGet()
        if (attempt > MAX_RECOVERY_ATTEMPTS_PER_PROCESS) {
            Log.w(TAG, "recoverCorruptCache: hit per-process limit ($attempt), giving up")
            emit(
                ModelDownloadState.Failed(
                    ARScannerError.ModelDownload(
                        "Model recovery limit reached; restart the app to retry.",
                    ),
                ),
            )
            return@flow
        }
        Log.w(TAG, "recoverCorruptCache: attempt $attempt — deleting cached models")
        val appCtx = context.applicationContext
        listOf(
            ModelPaths.classificationFile(appCtx),
            ModelPaths.segmentationFile(appCtx),
        ).forEach { f ->
            runCatching {
                if (f.exists() && !f.delete()) {
                    Log.w(TAG, "could not delete ${f.absolutePath}")
                }
            }
        }
        emitAll(downloadIfNeeded(appCtx, license, modelBaseURL))
    }

    private fun downloadOne(
        baseUrl: String,
        urlPath: String,
        target: File,
        license: ARScannerLicense,
    ): Flow<ModelDownloadState> = flow {
        val tmp = File(target.parentFile, "${target.name}.tmp")
        if (tmp.exists()) tmp.delete()

        val url = baseUrl.trimEnd('/') + "/" + urlPath
        val request = Request.Builder()
            .url(url)
            .apply {
                // Only send credentials to an origin that actually gates downloads.
                //
                // GitHub Release assets are public and 302-redirect to a storage host
                // with a pre-signed URL that carries its own credentials in the query
                // string. That host rejects a request presenting BOTH the pre-signed
                // query auth and an Authorization header — verified: following the
                // redirect with a Basic header returns 401, without it returns 200.
                // OkHttp drops Authorization on cross-host redirects, but the download
                // must not depend on that internal behaviour, so we never attach the
                // header for public origins in the first place.
                if (requiresDownloadAuth(url)) {
                    header("Authorization", basicAuth(license.key, license.key))
                }
            }
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("$urlPath HTTP ${response.code}")
            }
            val body = response.body ?: throw IOException("$urlPath empty body")
            val totalBytes = body.contentLength().takeIf { it > 0 }

            body.source().use { source ->
                tmp.sink().buffer().use { sink ->
                    var written = 0L
                    val buffer = okio.Buffer()
                    var lastEmit = 0L
                    while (true) {
                        val read = source.read(buffer, BUFFER_SIZE_BYTES)
                        if (read == -1L) break
                        sink.write(buffer, read)
                        written += read
                        val now = System.currentTimeMillis()
                        if (now - lastEmit > PROGRESS_EMIT_INTERVAL_MS) {
                            emit(
                                ModelDownloadState.InProgress(
                                    fileName = urlPath,
                                    bytesDownloaded = written,
                                    totalBytes = totalBytes,
                                ),
                            )
                            lastEmit = now
                        }
                    }
                    emit(
                        ModelDownloadState.InProgress(
                            fileName = urlPath,
                            bytesDownloaded = written,
                            totalBytes = totalBytes,
                        ),
                    )
                }
            }
        }

        if (!tmp.renameTo(target)) {
            tmp.delete()
            throw IOException("$urlPath could not be moved to ${target.name}")
        }
    }

    /**
     * Whether [url]'s origin gates downloads behind credentials.
     *
     * False for the public GitHub Release assets that 0.1.0 ships from; true for a
     * custom origin, so the license-gated Worker in `scripts/worker/` (kept as
     * future work) keeps working if [ARScannerConfiguration.modelBaseURL] is
     * pointed back at it.
     */
    private fun requiresDownloadAuth(url: String): Boolean {
        val host = url.toHttpUrlOrNull()?.host ?: return false
        return PUBLIC_ASSET_HOST_SUFFIXES.none { host == it || host.endsWith(".$it") }
    }

    private fun basicAuth(user: String, pass: String): String {
        val raw = "$user:$pass".toByteArray(Charsets.UTF_8)
        return "Basic " + Base64.encodeToString(raw, Base64.NO_WRAP)
    }

    private companion object {
        const val TAG = "ARScannerModelLoader"
        const val BUFFER_SIZE_BYTES = 64L * 1024L
        const val PROGRESS_EMIT_INTERVAL_MS = 200L
        const val MAX_RECOVERY_ATTEMPTS_PER_PROCESS = 2

        // Hosts serving the public 0.1.0 model assets: github.com issues the 302,
        // *.githubusercontent.com serves the pre-signed redirect target.
        val PUBLIC_ASSET_HOST_SUFFIXES = listOf("github.com", "githubusercontent.com")

        // Resets on each process start — same lifetime guarantee as
        // MLModel.recoveryAttempted in the Fishbuddy reference. Stops an
        // unreachable download server from putting the app in a delete/retry loop.
        val recoveryAttempts = AtomicInteger(0)
    }
}
