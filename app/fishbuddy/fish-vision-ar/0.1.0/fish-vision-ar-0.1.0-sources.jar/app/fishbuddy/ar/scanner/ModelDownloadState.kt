package app.fishbuddy.ar.scanner

/**
 * Lifecycle of an [ARScannerModelLoader.downloadIfNeeded] call. Drives consumer UI
 * (progress bar, retry button, "ready to scan" indicator).
 */
public sealed interface ModelDownloadState {

    /** Initial state. No work has been queued yet. */
    public data object NotStarted : ModelDownloadState

    /** Verifying which files (if any) are already cached on disk. */
    public data object CheckingCache : ModelDownloadState

    /**
     * Active download.
     *
     * @param fileName name of the model currently being downloaded.
     * @param bytesDownloaded total bytes written to disk for this file.
     * @param totalBytes content length if known, or `null` for chunked responses.
     */
    public data class InProgress(
        public val fileName: String,
        public val bytesDownloaded: Long,
        public val totalBytes: Long?,
    ) : ModelDownloadState

    /** All required models are on disk and verified. The scanner is ready to run. */
    public data object Completed : ModelDownloadState

    /** Terminal failure. Retry by calling [ARScannerModelLoader.downloadIfNeeded] again. */
    public data class Failed(public val error: ARScannerError) : ModelDownloadState
}
