package app.fishbuddy.ar.scanner.internal.ml

import android.media.Image
import android.opengl.Matrix
import android.util.Log
import app.fishbuddy.ar.scanner.internal.ScanFlags
import com.google.ar.core.CameraIntrinsics
import com.google.ar.core.Coordinates2d
import com.google.ar.core.Frame
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.ShortBuffer
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Computes a 3-D distance in metres between two CPU-image points, using ARCore's
 * raw depth + confidence images and the camera intrinsics.
 *
 * Distilled from `DepthData` — only the pieces needed when we already have two
 * specific endpoints (from [FishEndpointDetector]) and don't need the full
 * point-cloud-of-the-scene pipeline.
 */
/**
 * Outcome of one depth measurement, plus the raw per-endpoint samples behind it.
 *
 * The samples are captured *before* any recovery/substitution step, so a
 * validation-log row shows what the depth image actually contained rather than
 * what the measurement code made of it.
 *
 * @param meters head-to-tail distance, or `null` when the measurement was refused.
 * @param rejectReason why it was refused, or `""` when it wasn't.
 */
internal data class DepthMeasurement(
    val meters: Double?,
    val depthPx1: Pair<Int, Int> = -1 to -1,
    val depthPx2: Pair<Int, Int> = -1 to -1,
    val depth1mm: Float = -1f,
    val conf1: Float = -1f,
    val depth2mm: Float = -1f,
    val conf2: Float = -1f,
    val rejectReason: String = "",
)

internal object DepthMeasurer {

    /**
     * @return a [DepthMeasurement] whose `meters` is the distance between the two
     *   endpoints, or `null` if the depth sample at either endpoint is invalid
     *   (zero / out of frame).
     */
    fun measureMeters(
        frame: Frame,
        depthImage: Image,
        confidenceImage: Image,
        modelMatrix: FloatArray,
        cameraIntrinsics: CameraIntrinsics,
        cpuPoint1: MaskPoint,
        cpuPoint2: MaskPoint,
    ): DepthMeasurement {
        val depthW = depthImage.width
        val depthH = depthImage.height

        val cpuToDepth = buildCpuToDepthAffine(frame, depthW, depthH)

        Log.d(
            TAG,
            "measure: depthSize=${depthW}x$depthH cpuToDepth=${if (cpuToDepth != null) "ok" else "null"}",
        )

        // Safe fallbacks match Fishbuddy's DepthData: when the affine fails, try
        // the per-point coord transform; when *that* fails, fall back to the
        // depth-image centre (for point 1) or point 1 (for point 2). This is
        // strictly better than dying with `null` — a slightly wrong measurement
        // is more useful than no measurement.
        val depth1 = (cpuToDepth?.map(cpuPoint1.x.toFloat(), cpuPoint1.y.toFloat())
            ?: getDepthImageCoordinates(frame, depthW, depthH, cpuPoint1.x, cpuPoint1.y)
            ?: run {
                Log.w(TAG, "depth1 mapping failed for cpu=$cpuPoint1, falling back to depth-image centre")
                Pair(depthW / 2, depthH / 2)
            }).clampTo(depthW, depthH)
        val depth2 = (cpuToDepth?.map(cpuPoint2.x.toFloat(), cpuPoint2.y.toFloat())
            ?: getDepthImageCoordinates(frame, depthW, depthH, cpuPoint2.x, cpuPoint2.y)
            ?: run {
                Log.w(TAG, "depth2 mapping failed for cpu=$cpuPoint2, falling back to depth1=$depth1")
                depth1
            }).clampTo(depthW, depthH)
        Log.d(TAG, "cpu=$cpuPoint1->depth=$depth1   cpu=$cpuPoint2->depth=$depth2")

        val pointBuffer = depthEndpointsTo3D(
            depth1.first, depth1.second,
            depth2.first, depth2.second,
            depthImage,
            confidenceImage,
            cameraIntrinsics,
            modelMatrix,
        )

        // pointBuffer layout: [x1,y1,z1,conf1,depth1, x2,y2,z2,conf2,depth2]
        Log.d(
            TAG,
            "3D points: " +
                "p1=(${pointBuffer[0]},${pointBuffer[1]},${pointBuffer[2]}) " +
                "conf=${pointBuffer[3]} depth=${pointBuffer[4]}mm | " +
                "p2=(${pointBuffer[5]},${pointBuffer[6]},${pointBuffer[7]}) " +
                "conf=${pointBuffer[8]} depth=${pointBuffer[9]}mm",
        )
        // Raw samples, captured before the recovery block below rewrites them.
        val rawDepth1 = pointBuffer[4]
        val rawConf1 = pointBuffer[3]
        val rawDepth2 = pointBuffer[9]
        val rawConf2 = pointBuffer[8]
        fun measurement(meters: Double?, rejectReason: String = "") = DepthMeasurement(
            meters = meters,
            depthPx1 = depth1, depthPx2 = depth2,
            depth1mm = rawDepth1, conf1 = rawConf1,
            depth2mm = rawDepth2, conf2 = rawConf2,
            rejectReason = rejectReason,
        )

        // D3. The pre-fix branch below copies the good endpoint's confidence and
        // depth scalar onto the bad one — but the distance is computed purely from
        // the world coordinates (indices 0..2 and 5..7), which it leaves untouched.
        // A zero-depth endpoint unprojects to (0,0,0) in camera space, i.e. the
        // camera's own position in world space, so the "recovered" measurement is
        // camera-to-fish rather than head-to-tail. See ScanFlags.depthMeasureFixesEnabled.
        if (ScanFlags.depthMeasureFixesEnabled) {
            val bad = when {
                pointBuffer[3] == 0f -> "endpoint1"
                pointBuffer[8] == 0f -> "endpoint2"
                else -> null
            }
            if (bad != null) {
                Log.w(TAG, "$bad has zero depth confidence — refusing to measure")
                return measurement(null, "${bad}_zero_confidence")
            }
        } else if (pointBuffer[3] == 0f && pointBuffer[8] != 0f) {
            pointBuffer[3] = pointBuffer[8]; pointBuffer[4] = pointBuffer[9]
        } else if (pointBuffer[8] == 0f && pointBuffer[3] != 0f) {
            pointBuffer[8] = pointBuffer[3]; pointBuffer[9] = pointBuffer[4]
        }
        if (pointBuffer[3] == 0f && pointBuffer[8] == 0f) {
            Log.w(TAG, "both endpoints have zero depth confidence — returning null")
            return measurement(null, "both_endpoints_zero_confidence")
        }

        val dx = pointBuffer[0] - pointBuffer[5]
        val dy = pointBuffer[1] - pointBuffer[6]
        val dz = pointBuffer[2] - pointBuffer[7]
        return measurement(sqrt((dx * dx + dy * dy + dz * dz).toDouble()))
    }

    private const val TAG = "DepthMeasurer"

    // ------------------------------------------------------------------ CPU→depth
    private data class Affine2D(
        val a: Float, val b: Float, val c: Float,
        val d: Float, val e: Float, val f: Float,
    ) {
        fun map(x: Float, y: Float): Pair<Int, Int> =
            Pair((a * x + b * y + c).toInt(), (d * x + e * y + f).toInt())
    }

    private fun Pair<Int, Int>.clampTo(w: Int, h: Int) =
        Pair(first.coerceIn(0, w - 1), second.coerceIn(0, h - 1))

    private fun buildCpuToDepthAffine(frame: Frame, depthW: Int, depthH: Int): Affine2D? {
        // Solve an affine that maps three known CPU corner pixels to their
        // texture-normalised, then depth-pixel, equivalents.
        val cpuW = frame.camera.imageIntrinsics.imageDimensions[0].toFloat()
        val cpuH = frame.camera.imageIntrinsics.imageDimensions[1].toFloat()

        fun cpuToDepthPx(x: Float, y: Float): FloatArray? {
            val inPx = floatArrayOf(x, y)
            val outUv = FloatArray(2)
            frame.transformCoordinates2d(
                Coordinates2d.IMAGE_PIXELS, inPx,
                Coordinates2d.TEXTURE_NORMALIZED, outUv,
            )
            val eps = 1e-6f
            if (outUv[0] < -eps || outUv[0] > 1f + eps ||
                outUv[1] < -eps || outUv[1] > 1f + eps
            ) return null
            return floatArrayOf(outUv[0] * depthW, outUv[1] * depthH)
        }

        val pCpu = arrayOf(
            floatArrayOf(0f, 0f),
            floatArrayOf(cpuW, 0f),
            floatArrayOf(0f, cpuH),
        )
        val pDepth = pCpu.map { cpuToDepthPx(it[0], it[1]) ?: return null }

        val x1 = pCpu[0][0]; val y1 = pCpu[0][1]; val u1 = pDepth[0][0]; val v1 = pDepth[0][1]
        val x2 = pCpu[1][0]; val y2 = pCpu[1][1]; val u2 = pDepth[1][0]; val v2 = pDepth[1][1]
        val x3 = pCpu[2][0]; val y3 = pCpu[2][1]; val u3 = pDepth[2][0]; val v3 = pDepth[2][1]

        // Solve [a b c; d e f] · [x y 1]ᵀ = [u v]ᵀ via Cramer's rule.
        val det = x1 * (y2 - y3) - y1 * (x2 - x3) + (x2 * y3 - x3 * y2)
        if (abs(det) < 1e-6f) return null
        val a = (u1 * (y2 - y3) - y1 * (u2 - u3) + (u2 * y3 - u3 * y2)) / det
        val b = (x1 * (u2 - u3) - u1 * (x2 - x3) + (x2 * u3 - x3 * u2)) / det
        val c = (x1 * (y2 * u3 - y3 * u2) - y1 * (x2 * u3 - x3 * u2) + u1 * (x2 * y3 - x3 * y2)) / det
        val d = (v1 * (y2 - y3) - y1 * (v2 - v3) + (v2 * y3 - v3 * y2)) / det
        val e = (x1 * (v2 - v3) - v1 * (x2 - x3) + (x2 * v3 - x3 * v2)) / det
        val f = (x1 * (y2 * v3 - y3 * v2) - y1 * (x2 * v3 - x3 * v2) + v1 * (x2 * y3 - x3 * y2)) / det
        return Affine2D(a, b, c, d, e, f)
    }

    private fun getDepthImageCoordinates(
        frame: Frame,
        depthW: Int,
        depthH: Int,
        cpuX: Int,
        cpuY: Int,
    ): Pair<Int, Int>? {
        val cpuCoords = floatArrayOf(cpuX.toFloat(), cpuY.toFloat())
        val tex = FloatArray(2)
        frame.transformCoordinates2d(
            Coordinates2d.IMAGE_PIXELS, cpuCoords,
            Coordinates2d.TEXTURE_NORMALIZED, tex,
        )
        if (tex[0] < 0f || tex[1] < 0f) return null
        val x = (tex[0] * depthW).toInt().coerceIn(0, depthW - 1)
        val y = (tex[1] * depthH).toInt().coerceIn(0, depthH - 1)
        return Pair(x, y)
    }

    // ------------------------------------------------------------------ depth→3D

    private fun depthEndpointsTo3D(
        x1: Int, y1: Int,
        x2: Int, y2: Int,
        depth: Image,
        confidence: Image,
        cameraTextureIntrinsics: CameraIntrinsics,
        modelMatrix: FloatArray,
    ): FloatArray {
        val depthPlane = depth.planes[0]
        val depthByteBufferOriginal = depthPlane.buffer
        val depthByteBuffer = ByteBuffer.allocate(depthByteBufferOriginal.capacity())
            .order(ByteOrder.LITTLE_ENDIAN)
        while (depthByteBufferOriginal.hasRemaining()) {
            depthByteBuffer.put(depthByteBufferOriginal.get())
        }
        depthByteBuffer.rewind()
        val depthBuffer: ShortBuffer = depthByteBuffer.asShortBuffer()

        val confPlane = confidence.planes[0]
        val confBufOrig = confPlane.buffer
        val confBuf = ByteBuffer.allocate(confBufOrig.capacity()).order(ByteOrder.LITTLE_ENDIAN)
        while (confBufOrig.hasRemaining()) {
            confBuf.put(confBufOrig.get())
        }
        confBuf.rewind()

        val intrinsicsDims = cameraTextureIntrinsics.imageDimensions
        val depthWidth = depth.width
        val depthHeight = depth.height
        val fx = cameraTextureIntrinsics.focalLength[0] * depthWidth / intrinsicsDims[0]
        val fy = cameraTextureIntrinsics.focalLength[1] * depthHeight / intrinsicsDims[1]
        val cx = cameraTextureIntrinsics.principalPoint[0] * depthWidth / intrinsicsDims[0]
        val cy = cameraTextureIntrinsics.principalPoint[1] * depthHeight / intrinsicsDims[1]

        val t1 = projectDepthPoint(x1, y1, depthWidth, depthHeight, depthBuffer, cx, cy, fx, fy, modelMatrix, confBuf, confPlane)
        val t2 = projectDepthPoint(x2, y2, depthWidth, depthHeight, depthBuffer, cx, cy, fx, fy, modelMatrix, confBuf, confPlane)
        return floatArrayOf(
            t1[0], t1[1], t1[2], t1[3], t1[4],
            t2[0], t2[1], t2[2], t2[3], t2[4],
        )
    }

    /**
     * One endpoint's depth reading: the value used for unprojection, its
     * confidence, and how many samples of the patch survived the confidence gate
     * ([kept] of [total]). With D4 off, this is a single pixel and
     * `kept == total == 1`.
     */
    private data class DepthSample(
        val depthMillimeters: Float,
        val confidence: Float,
        val kept: Int,
        val total: Int,
    )

    /**
     * Median depth over a patch centred on ([x], [y]), keeping only samples that
     * clear the confidence gate and carry a non-zero depth.
     *
     * Raw depth is noisiest exactly at object boundaries, which is where a fish's
     * snout and tail sit, so a lone pixel is a poor estimator. The median is
     * robust to the boundary pixels that read the background instead of the fish.
     */
    private fun sampleDepthPatch(
        x: Int,
        y: Int,
        depthWidth: Int,
        depthHeight: Int,
        depthBuffer: ShortBuffer,
        confidenceBuffer: ByteBuffer,
        confidencePlane: Image.Plane,
    ): DepthSample {
        fun confidenceAt(px: Int, py: Int): Float {
            val b = confidenceBuffer[py * confidencePlane.rowStride + px * confidencePlane.pixelStride]
            return (b.toInt() and 0xFF) / 255.0f
        }

        if (!ScanFlags.depthPatchSamplingEnabled) {
            val mm = depthBuffer[y * depthWidth + x].toInt().toFloat()
            return DepthSample(mm, confidenceAt(x, y), kept = 1, total = 1)
        }

        val r = ScanFlags.DEPTH_PATCH_RADIUS
        val depths = mutableListOf<Float>()
        val confidences = mutableListOf<Float>()
        var total = 0
        for (dy in -r..r) {
            for (dx in -r..r) {
                val px = x + dx
                val py = y + dy
                if (px < 0 || py < 0 || px >= depthWidth || py >= depthHeight) continue
                total++
                val mm = depthBuffer[py * depthWidth + px].toInt().toFloat()
                val conf = confidenceAt(px, py)
                if (mm <= 0f || conf < ScanFlags.DEPTH_CONFIDENCE_THRESHOLD) continue
                depths += mm
                confidences += conf
            }
        }
        if (depths.size < ScanFlags.MIN_CONFIDENT_DEPTH_SAMPLES) {
            // Report zero confidence so the caller's existing gate refuses the scan.
            return DepthSample(0f, 0f, kept = depths.size, total = total)
        }
        depths.sort()
        confidences.sort()
        return DepthSample(
            depthMillimeters = depths[depths.size / 2],
            confidence = confidences[confidences.size / 2],
            kept = depths.size,
            total = total,
        )
    }

    private fun projectDepthPoint(
        x: Int,
        y: Int,
        depthWidth: Int,
        depthHeight: Int,
        depthBuffer: ShortBuffer,
        cx: Float,
        cy: Float,
        fx: Float,
        fy: Float,
        modelMatrix: FloatArray,
        confidenceBuffer: ByteBuffer,
        confidencePlane: Image.Plane,
    ): FloatArray {
        val pointCamera = FloatArray(4)
        val pointWorld = FloatArray(4)
        val out = FloatArray(5)

        val sample = sampleDepthPatch(
            x, y, depthWidth, depthHeight, depthBuffer, confidenceBuffer, confidencePlane,
        )
        val depthMillimeters = sample.depthMillimeters
        val depthMeters = depthMillimeters / 1000.0f
        val confidenceNormalized = sample.confidence

        pointCamera[0] = depthMeters * (x - cx) / fx
        pointCamera[1] = depthMeters * (cy - y) / fy
        pointCamera[2] = -depthMeters
        pointCamera[3] = 1f
        Matrix.multiplyMV(pointWorld, 0, modelMatrix, 0, pointCamera, 0)

        out[0] = pointWorld[0]
        out[1] = pointWorld[1]
        out[2] = pointWorld[2]
        out[3] = confidenceNormalized
        out[4] = depthMillimeters
        return out
    }
}
