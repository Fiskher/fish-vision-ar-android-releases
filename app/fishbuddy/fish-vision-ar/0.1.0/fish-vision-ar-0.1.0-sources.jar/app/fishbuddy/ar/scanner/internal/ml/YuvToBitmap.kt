package app.fishbuddy.ar.scanner.internal.ml

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import android.media.Image
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer

/**
 * Converts an ARCore `Frame.acquireCameraImage()` (always YUV_420_888) to an
 * ARGB_8888 [Bitmap].
 *
 * Implementation goes YUV_420_888 → NV21 → JPEG → Bitmap. Not the fastest possible
 * path, but handles all device pixel-stride/row-stride variations correctly without
 * pulling in RenderScript (deprecated) or a custom native YUV decoder.
 */
internal object YuvToBitmap {

    fun convert(image: Image, jpegQuality: Int = 90): Bitmap {
        require(image.format == ImageFormat.YUV_420_888) {
            "Expected YUV_420_888, got ${image.format}"
        }
        val nv21 = yuv420ToNv21(image)
        val yuvImage = YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null)
        val out = ByteArrayOutputStream()
        yuvImage.compressToJpeg(Rect(0, 0, image.width, image.height), jpegQuality, out)
        val bytes = out.toByteArray()
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    /**
     * Pack a YUV_420_888 [Image] into an NV21 byte array, honouring row strides
     * and chroma pixel strides. NV21 layout: full Y plane, then interleaved VU.
     */
    private fun yuv420ToNv21(image: Image): ByteArray {
        val width = image.width
        val height = image.height
        val ySize = width * height
        val uvSize = width * height / 2
        val nv21 = ByteArray(ySize + uvSize)

        // Y plane
        val yPlane = image.planes[0]
        copyPlane(yPlane.buffer, yPlane.rowStride, yPlane.pixelStride, width, height, nv21, 0)

        // VU plane (NV21 is V/U interleaved)
        val uPlane = image.planes[1]
        val vPlane = image.planes[2]
        val uBuffer = uPlane.buffer
        val vBuffer = vPlane.buffer
        val uRowStride = uPlane.rowStride
        val vRowStride = vPlane.rowStride
        val uPixelStride = uPlane.pixelStride
        val vPixelStride = vPlane.pixelStride

        val chromaW = width / 2
        val chromaH = height / 2
        var dst = ySize
        for (row in 0 until chromaH) {
            val vRowStart = row * vRowStride
            val uRowStart = row * uRowStride
            for (col in 0 until chromaW) {
                nv21[dst] = vBuffer.get(vRowStart + col * vPixelStride)
                nv21[dst + 1] = uBuffer.get(uRowStart + col * uPixelStride)
                dst += 2
            }
        }
        return nv21
    }

    private fun copyPlane(
        buffer: ByteBuffer,
        rowStride: Int,
        pixelStride: Int,
        width: Int,
        height: Int,
        out: ByteArray,
        outOffset: Int,
    ) {
        var dst = outOffset
        if (pixelStride == 1 && rowStride == width) {
            buffer.get(out, dst, width * height)
            return
        }
        val rowBuffer = ByteArray(rowStride)
        for (row in 0 until height) {
            val pos = row * rowStride
            buffer.position(pos)
            val toRead = minOf(rowStride, buffer.remaining())
            buffer.get(rowBuffer, 0, toRead)
            if (pixelStride == 1) {
                System.arraycopy(rowBuffer, 0, out, dst, width)
                dst += width
            } else {
                var src = 0
                for (col in 0 until width) {
                    out[dst++] = rowBuffer[src]
                    src += pixelStride
                }
            }
        }
    }
}
