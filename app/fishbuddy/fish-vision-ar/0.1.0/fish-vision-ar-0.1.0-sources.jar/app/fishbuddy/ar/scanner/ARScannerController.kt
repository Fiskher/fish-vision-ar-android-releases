package app.fishbuddy.ar.scanner

import android.graphics.Bitmap
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Controls the AR scanner session. One instance per screen; survives configuration
 * changes when hoisted into a `ViewModel`.
 *
 * Methods are safe to call from the main thread; long-running work is dispatched
 * internally to background coroutines. When no [ARScannerView] is currently in the
 * composition, mutating calls are no-ops.
 */
public class ARScannerController {

    private val _state: MutableStateFlow<ARScannerState> =
        MutableStateFlow(ARScannerState.Idle)

    /** Observable session state. Drives UI affordances (busy indicators, retry buttons). */
    public val state: StateFlow<ARScannerState> = _state.asStateFlow()

    @Volatile
    internal var engine: ControllerEngine? = null

    internal fun updateState(state: ARScannerState) {
        _state.value = state
    }

    /**
     * Capture the current AR frame, run classification + measurement, emit the
     * result via the host view's `onScan` callback.
     */
    public fun captureAndScan() {
        engine?.captureAndScan()
    }

    /**
     * Classify a still image (e.g. from the gallery). Skips ARCore measurement.
     * Suspends until the model run completes.
     */
    public suspend fun classify(bitmap: Bitmap) {
        engine?.classify(bitmap)
    }

    /** Detach anchors and return to [ARScannerState.Ready] (or [ARScannerState.Idle] if no view). */
    public fun reset() {
        val current = engine
        if (current != null) {
            current.reset()
            _state.value = ARScannerState.Ready
        } else {
            _state.value = ARScannerState.Idle
        }
    }
}

/** Internal handle that an active [ARScannerView] registers with its controller. */
internal interface ControllerEngine {
    fun captureAndScan()
    suspend fun classify(bitmap: Bitmap)
    fun reset()
}
