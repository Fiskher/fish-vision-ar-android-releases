package app.fishbuddy.ar.scanner.internal.ml

import app.fishbuddy.ar.scanner.internal.ScanFlags
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/**
 * Locates two endpoints (head + tail) along a fish silhouette in a segmentation mask.
 *
 * Port of `ScanViewModel.parseOutput2` — the row-averaging / column-averaging logic.
 * Picks whichever axis (vertical or horizontal) carries the longer fish silhouette,
 * then takes the centre-line endpoints at the silhouette's extremes along that axis.
 *
 * Returns the two endpoints in coordinates of the *original* (un-cropped, un-scaled)
 * source image — caller-supplied [cropInfo] handles the offset and the
 * mask-to-source scaling.
 */
internal object FishEndpointDetector {

    /**
     * @param mask flat segmentation output, length = `maskWidth * maskHeight`.
     *   Iteration order matches `parseOutput2`: outer = y, inner = x.
     * @param maskWidth width of the segmentation output (typically 384 or 448).
     * @param maskHeight height of the segmentation output.
     * @param cropInfo geometry produced by [ImageCrop.cropToPortrait3x4].
     * @param confidenceThreshold pixels with mask confidence ≥ this are fish.
     * @return `Pair(head, tail)` in source-image coordinates, or `null` if the mask
     *   contains no fish pixels above the threshold.
     */
    fun detect(
        mask: FloatArray,
        maskWidth: Int,
        maskHeight: Int,
        cropInfo: CropInfo,
        confidenceThreshold: Float = 0.5f,
    ): Pair<MaskPoint, MaskPoint>? {
        // Keep only the largest contiguous blob — discards stray pixels (shadows,
        // floor texture, distant noise) that would otherwise stretch endpoints far
        // beyond the fish's actual extent. Without this, a 35 cm fish on a wooden
        // floor often gets ~99 cm measurements because the mask includes scattered
        // floor pixels along the major axis.
        val filtered = largestConnectedComponent(mask, maskWidth, maskHeight, confidenceThreshold)

        if (ScanFlags.endpointPcaEnabled) {
            val pca = principalAxisEndpoints(filtered, maskWidth, maskHeight, confidenceThreshold)
            if (pca != null) {
                return pca.first.toSourceCoords(cropInfo, maskWidth, maskHeight) to
                    pca.second.toSourceCoords(cropInfo, maskWidth, maskHeight)
            }
            return null
        }

        val twoD = Array(maskWidth) { IntArray(maskHeight) }
        val vertX = mutableListOf<Int>()
        val vertY = mutableListOf<Int>()
        val horX = mutableListOf<Int>()
        val horY = mutableListOf<Int>()

        var i = 0
        for (y in 0 until maskHeight) {
            var sum = 0
            var len = 0
            for (x in 0 until maskWidth) {
                if (filtered[i] > confidenceThreshold) {
                    twoD[x][y] = 1
                    sum += x
                    len++
                }
                i++
            }
            if (len > 0) {
                vertX.add(sum / len)
                vertY.add(y)
            }
        }
        if (vertY.isEmpty()) return null

        for (x in 0 until maskWidth) {
            var sum = 0
            var len = 0
            for (y in 0 until maskHeight) {
                if (twoD[x][y] > 0) {
                    sum += y
                    len++
                }
            }
            if (len > 0) {
                horX.add(x)
                horY.add(sum / len)
            }
        }
        if (horX.isEmpty()) return null

        val distVert = vertY.max() - vertY.min()
        val distHor = horX.max() - horX.min()
        val (startX, startY, endX, endY) = if (distHor >= distVert) {
            val minIdx = horX.indexOf(horX.min())
            val maxIdx = horX.indexOf(horX.max())
            intArrayOf(horX[minIdx], horY[minIdx], horX[maxIdx], horY[maxIdx])
        } else {
            val minIdx = vertY.indexOf(vertY.min())
            val maxIdx = vertY.indexOf(vertY.max())
            intArrayOf(vertX[minIdx], vertY[minIdx], vertX[maxIdx], vertY[maxIdx])
        }

        // Mask → cropped image space.
        val scaleToCroppedW = cropInfo.width.toDouble() / maskWidth.toDouble()
        val scaleToCroppedH = cropInfo.height.toDouble() / maskHeight.toDouble()
        val sCroppedX = (startX * scaleToCroppedW).toInt()
        val sCroppedY = (startY * scaleToCroppedH).toInt()
        val eCroppedX = (endX * scaleToCroppedW).toInt()
        val eCroppedY = (endY * scaleToCroppedH).toInt()

        // Cropped → original (absolute) image space.
        val sAbsX = sCroppedX + cropInfo.left
        val sAbsY = sCroppedY + cropInfo.top
        val eAbsX = eCroppedX + cropInfo.left
        val eAbsY = eCroppedY + cropInfo.top

        return MaskPoint(sAbsX, sAbsY) to MaskPoint(eAbsX, eAbsY)
    }

    /**
     * Endpoints at the extreme projections onto the mask's principal axis.
     *
     * Runs a 2x2 PCA over the fish pixels: the major eigenvector of the
     * covariance matrix is the body axis, and its angle comes from the closed
     * form `0.5 * atan2(2*Sxy, Sxx - Syy)` — no iterative solver needed for 2x2.
     * Each pixel is projected onto that axis and the two extremes are returned.
     *
     * Returns the actual extreme *pixels* rather than points on the axis line, so
     * both endpoints are guaranteed to lie on the silhouette. That matters
     * downstream: the endpoints are where depth is sampled, and a point floating
     * just off the fish would read background depth instead.
     *
     * @return `Pair(head, tail)` in mask coordinates, or `null` if the mask has
     *   no pixels above [threshold].
     */
    private fun principalAxisEndpoints(
        mask: FloatArray,
        w: Int,
        h: Int,
        threshold: Float,
    ): Pair<MaskPoint, MaskPoint>? {
        var count = 0
        var sumX = 0.0
        var sumY = 0.0
        for (y in 0 until h) {
            for (x in 0 until w) {
                if (mask[y * w + x] > threshold) {
                    count++; sumX += x; sumY += y
                }
            }
        }
        if (count == 0) return null
        val meanX = sumX / count
        val meanY = sumY / count

        var sxx = 0.0
        var syy = 0.0
        var sxy = 0.0
        for (y in 0 until h) {
            for (x in 0 until w) {
                if (mask[y * w + x] <= threshold) continue
                val dx = x - meanX
                val dy = y - meanY
                sxx += dx * dx; syy += dy * dy; sxy += dx * dy
            }
        }
        sxx /= count; syy /= count; sxy /= count

        // Major-axis angle of a 2x2 covariance matrix, closed form. When the
        // distribution is isotropic (a disc, or a single pixel) this degenerates
        // to 0 and the axis is horizontal — harmless, as any axis is equally
        // valid for a shape with no dominant direction.
        val theta = 0.5 * atan2(2.0 * sxy, sxx - syy)
        val axisX = cos(theta)
        val axisY = sin(theta)

        var minT = Double.MAX_VALUE
        var maxT = -Double.MAX_VALUE
        var minPoint = MaskPoint(0, 0)
        var maxPoint = MaskPoint(0, 0)
        for (y in 0 until h) {
            for (x in 0 until w) {
                if (mask[y * w + x] <= threshold) continue
                val t = (x - meanX) * axisX + (y - meanY) * axisY
                if (t < minT) { minT = t; minPoint = MaskPoint(x, y) }
                if (t > maxT) { maxT = t; maxPoint = MaskPoint(x, y) }
            }
        }
        return minPoint to maxPoint
    }

    /** Mask coordinates to original-image coordinates, via the crop geometry. */
    private fun MaskPoint.toSourceCoords(
        cropInfo: CropInfo,
        maskWidth: Int,
        maskHeight: Int,
    ): MaskPoint {
        val scaleW = cropInfo.width.toDouble() / maskWidth.toDouble()
        val scaleH = cropInfo.height.toDouble() / maskHeight.toDouble()
        return MaskPoint(
            (x * scaleW).toInt() + cropInfo.left,
            (y * scaleH).toInt() + cropInfo.top,
        )
    }

    /**
     * Finds the largest contiguous region of pixels above [threshold] via BFS and
     * returns a new mask where only those pixels survive (everything else is `0f`).
     * 4-connectivity (up/down/left/right) — diagonal neighbours don't count, same
     * as the standard binary segmentation post-processing.
     *
     * O(W × H) time, O(W × H) auxiliary memory. For a 400×400 mask that's 160 k
     * cells — sub-millisecond on any modern phone.
     */
    private fun largestConnectedComponent(
        mask: FloatArray,
        w: Int,
        h: Int,
        threshold: Float,
    ): FloatArray {
        val n = w * h
        val visited = BooleanArray(n)
        var bestSize = 0
        var bestComponent: IntArray = IntArray(0)
        val queue = IntArray(n)
        val current = IntArray(n)

        for (start in 0 until n) {
            if (visited[start] || mask[start] <= threshold) continue
            var qHead = 0
            var qTail = 0
            var cSize = 0
            queue[qTail++] = start
            visited[start] = true

            while (qHead < qTail) {
                val idx = queue[qHead++]
                current[cSize++] = idx
                val x = idx % w
                val y = idx / w
                if (x > 0) {
                    val ni = idx - 1
                    if (!visited[ni] && mask[ni] > threshold) {
                        visited[ni] = true; queue[qTail++] = ni
                    }
                }
                if (x + 1 < w) {
                    val ni = idx + 1
                    if (!visited[ni] && mask[ni] > threshold) {
                        visited[ni] = true; queue[qTail++] = ni
                    }
                }
                if (y > 0) {
                    val ni = idx - w
                    if (!visited[ni] && mask[ni] > threshold) {
                        visited[ni] = true; queue[qTail++] = ni
                    }
                }
                if (y + 1 < h) {
                    val ni = idx + w
                    if (!visited[ni] && mask[ni] > threshold) {
                        visited[ni] = true; queue[qTail++] = ni
                    }
                }
            }
            if (cSize > bestSize) {
                bestSize = cSize
                bestComponent = current.copyOf(cSize)
            }
        }

        if (bestSize == 0) return mask // nothing above threshold — return as-is
        val out = FloatArray(n)
        for (idx in bestComponent) out[idx] = mask[idx]
        return out
    }

    private operator fun IntArray.component3(): Int = this[2]
    private operator fun IntArray.component4(): Int = this[3]
}
