package app.fishbuddy.ar.scanner.internal.diagnostics

import android.content.Context
import android.os.Build
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Ground-truth validation harness — Phase 0 of `fishbuddy_android`'s
 * `docs/scanner-accuracy-improvements.md`, ported to the SDK.
 *
 * Debug tooling only: it **observes** the scanner and never changes a
 * measurement. Every completed depth measurement appends one CSV row, so an
 * error distribution (mean / p50 / p95 / worst) can be built against a
 * known-length target photographed at several distances and angles. That
 * baseline is what the D3 / D4 / D5 / D6 fixes are measured against — without
 * it, no accuracy claim about them is checkable.
 *
 * **Off by default and must stay off in anything a customer ships.** Unlike the
 * app — which flips a `const val` and recompiles — this is a `@Volatile var`,
 * because the SDK is consumed as a binary AAR: an engineer can enable it from a
 * debug build without rebuilding the library, and no consumer gets file writes
 * unless they deliberately opt in. Nothing in the SDK ever sets it to `true`.
 *
 * All work is wrapped in `runCatching`, so a logging failure can never break a
 * scan.
 *
 * Pull the log off-device:
 * ```
 * adb pull /sdcard/Android/data/<pkg>/files/scan_validation/measurements.csv
 * ```
 */
internal object ScanValidationLogger {

    /**
     * Master switch — the SDK equivalent of the app's `SCAN_VALIDATION_LOGGING`.
     * Leave `false`; set it only from a debug build you control.
     */
    @Volatile
    var enabled: Boolean = false

    private const val TAG = "ScanValidation"
    private const val DIR = "scan_validation"
    private const val FILE = "measurements.csv"

    private const val HEADER =
        "timestamp,device,path,trueLengthCm,distanceM,angleDeg,note," +
            "lengthCm,errorCm," +
            "p1x,p1y,p2x,p2y,d1x,d1y,d2x,d2y,depth1mm,conf1,depth2mm,conf2," +
            "rejectReason,fishPixelFraction,speciesTop1,speciesScore"

    /** Phase 5 (D6) temporal-aggregation diagnostic. Populated once D6 lands. */
    private const val FILE_TEMPORAL = "temporal.csv"

    private const val HEADER_TEMPORAL =
        "timestamp,device,trueLengthCm,lengthCm,errorCm,uncertaintyCm," +
            "rawSamples,keptSamples,speciesTop1,speciesScore"

    /** Measurement path that produced the row. */
    const val PATH_DEPTH = "DEPTH"

    @Volatile
    private var appContext: Context? = null

    // ── Ground-truth session labels ─────────────────────────────────────────
    // Set these before a calibration run so each row is self-labelled and the
    // error column is computed automatically. -1 = unset.

    @Volatile
    var sessionTrueLengthCm: Double = -1.0

    @Volatile
    var sessionDistanceM: Double = -1.0

    @Volatile
    var sessionAngleDeg: Double = -1.0

    @Volatile
    var sessionNote: String = ""

    // SimpleDateFormat is not thread-safe; every write goes through a
    // @Synchronized method, so one guarded instance is fine.
    private val timestampFmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", Locale.US)

    fun init(context: Context) {
        if (!enabled) return
        appContext = context.applicationContext
    }

    private fun logFile(name: String, header: String): File? {
        val ctx = appContext ?: return null
        val dir = File(ctx.getExternalFilesDir(null), DIR)
        if (!dir.exists() && !dir.mkdirs()) return null
        val f = File(dir, name)
        if (!f.exists()) f.appendText(header + "\n")
        return f
    }

    private fun f1(v: Float) = "%.1f".format(Locale.US, v)
    private fun f3(v: Float) = "%.3f".format(Locale.US, v)
    private fun f2(v: Double) = "%.2f".format(Locale.US, v)
    private fun clean(s: String) = s.replace(",", " ")

    /**
     * Append one measurement row.
     *
     * @param lengthCm measured length, or `null` when the measurement was
     *   rejected — rejected attempts are logged too, since "how often does it
     *   refuse" is exactly what the D3/D4 gates change.
     * @param rejectReason why the measurement was refused, or `""` when it wasn't.
     */
    @Synchronized
    fun logMeasurement(
        path: String,
        lengthCm: Double?,
        p1x: Int, p1y: Int, p2x: Int, p2y: Int,
        d1x: Int = -1, d1y: Int = -1, d2x: Int = -1, d2y: Int = -1,
        depth1mm: Float = -1f, conf1: Float = -1f,
        depth2mm: Float = -1f, conf2: Float = -1f,
        rejectReason: String = "",
        fishPixelFraction: Float = -1f,
        speciesTop1: String = "",
        speciesScore: Double = -1.0,
    ) {
        if (!enabled) return
        runCatching {
            val errorCm = if (lengthCm != null && sessionTrueLengthCm > 0.0) {
                f2(lengthCm - sessionTrueLengthCm)
            } else {
                ""
            }
            val row = listOf(
                timestampFmt.format(Date()),
                clean("${Build.MANUFACTURER} ${Build.MODEL}"),
                path,
                if (sessionTrueLengthCm > 0.0) f2(sessionTrueLengthCm) else "",
                if (sessionDistanceM > 0.0) f2(sessionDistanceM) else "",
                if (sessionAngleDeg >= 0.0) "%.1f".format(Locale.US, sessionAngleDeg) else "",
                clean(sessionNote),
                lengthCm?.let { f2(it) } ?: "",
                errorCm,
                p1x, p1y, p2x, p2y,
                d1x, d1y, d2x, d2y,
                f1(depth1mm), f3(conf1), f1(depth2mm), f3(conf2),
                clean(rejectReason),
                f3(fishPixelFraction),
                clean(speciesTop1),
                if (speciesScore >= 0.0) f3(speciesScore.toFloat()) else "",
            ).joinToString(",")
            logFile(FILE, HEADER)?.appendText(row + "\n")
            Log.d(TAG, "logged $path len=${lengthCm?.let { f2(it) } ?: "rejected($rejectReason)"}")
        }.onFailure { Log.w(TAG, "validation log failed", it) }
    }

    /**
     * Phase 5 (D6) — one row per aggregated scan: median length, its ±σ band,
     * and the raw/kept sample counts. Lets us confirm σ tracks the observed
     * frame-to-frame spread. Unused until D6 lands.
     */
    @Synchronized
    fun logTemporal(
        lengthCm: Double,
        uncertaintyCm: Double,
        rawSamples: Int,
        keptSamples: Int,
        speciesTop1: String = "",
        speciesScore: Double = -1.0,
    ) {
        if (!enabled) return
        runCatching {
            val errorCm = if (sessionTrueLengthCm > 0.0) f2(lengthCm - sessionTrueLengthCm) else ""
            val row = listOf(
                timestampFmt.format(Date()),
                clean("${Build.MANUFACTURER} ${Build.MODEL}"),
                if (sessionTrueLengthCm > 0.0) f2(sessionTrueLengthCm) else "",
                f2(lengthCm), errorCm, f2(uncertaintyCm),
                rawSamples, keptSamples,
                clean(speciesTop1),
                if (speciesScore >= 0.0) f3(speciesScore.toFloat()) else "",
            ).joinToString(",")
            logFile(FILE_TEMPORAL, HEADER_TEMPORAL)?.appendText(row + "\n")
            Log.d(TAG, "temporal len=${f2(lengthCm)} ±${f2(uncertaintyCm)} kept=$keptSamples/$rawSamples")
        }.onFailure { Log.w(TAG, "temporal log failed", it) }
    }
}
