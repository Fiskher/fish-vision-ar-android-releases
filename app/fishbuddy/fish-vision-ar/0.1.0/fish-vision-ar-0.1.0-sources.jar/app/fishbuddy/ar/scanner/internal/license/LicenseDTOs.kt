package app.fishbuddy.ar.scanner.internal.license

import org.json.JSONObject

/**
 * Wire-format DTOs for `POST /v1/license/validate` and the JWT payload it returns.
 *
 * Field names match the iOS SDK's Codable definitions and the backend's
 * Swift/Kotlin definitions exactly — DO NOT camelCase ↔ snake_case convert.
 * Parsing tolerates unknown fields so backend additions don't break old SDKs.
 */
internal data class LicenseValidateRequest(
    val licenseKey: String,
    val bundleId: String,
    val deviceHash: String,
) {
    fun toJson(): String =
        JSONObject()
            .put("licenseKey", licenseKey)
            .put("bundleId", bundleId)
            .put("deviceHash", deviceHash)
            .toString()
}

internal data class LicenseQuotas(
    val scansPerMonth: Int?,
) {
    companion object {
        fun fromJson(obj: JSONObject?): LicenseQuotas {
            if (obj == null) return LicenseQuotas(scansPerMonth = null)
            val raw = obj.opt("scansPerMonth")
            val scans = when (raw) {
                null, JSONObject.NULL -> null
                is Number -> raw.toInt()
                else -> null
            }
            return LicenseQuotas(scansPerMonth = scans)
        }
    }
}

internal data class LicenseValidateResponse(
    val jwt: String,
    /** ISO 8601 UTC timestamp — the backend emits e.g. `2026-07-15T07:21:34Z`. */
    val expiresAt: String,
    val tenantId: String,
    val quotas: LicenseQuotas,
) {
    companion object {
        fun fromJson(body: String): LicenseValidateResponse {
            val obj = JSONObject(body)
            return LicenseValidateResponse(
                jwt = obj.getString("jwt"),
                expiresAt = obj.getString("expiresAt"),
                tenantId = obj.getString("tenantId"),
                quotas = LicenseQuotas.fromJson(obj.optJSONObject("quotas")),
            )
        }
    }
}

/**
 * Verified license JWT claims. `iat`/`exp` are Unix seconds.
 */
internal data class LicenseJWTClaims(
    val iss: String,
    val sub: String,
    val aud: String,
    val iat: Long,
    val exp: Long,
    val quotas: LicenseQuotas,
) {
    companion object {
        fun fromJson(payload: String): LicenseJWTClaims {
            val obj = JSONObject(payload)
            return LicenseJWTClaims(
                iss = obj.getString("iss"),
                sub = obj.getString("sub"),
                aud = obj.getString("aud"),
                iat = obj.getLong("iat"),
                exp = obj.getLong("exp"),
                quotas = LicenseQuotas.fromJson(obj.optJSONObject("quotas")),
            )
        }
    }
}
