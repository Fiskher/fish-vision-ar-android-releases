package app.fishbuddy.ar.scanner

/**
 * Telemetry opt-in. Default is [Disabled] — no scan data leaves the device unless
 * the customer explicitly constructs an [Enabled] instance and obtains user consent.
 *
 * See `docs/data-safety.md` for the contractual data-collection spec.
 */
public sealed interface ARScannerDataContribution {

    /** No telemetry. The SDK does not contact the backend except for license validation. */
    public data object Disabled : ARScannerDataContribution

    /**
     * Per-scan telemetry uploaded to the FishVisionAR backend.
     *
     * @param consent invoked before each upload. Return `false` to skip this scan.
     * @param metadata invoked alongside [consent] to attach optional metadata
     *   (hashed user id, coarse location, weather). Return `null` to upload the
     *   bare scan with no metadata.
     */
    public class Enabled(
        public val consent: suspend () -> Boolean,
        public val metadata: suspend () -> ARScanMetadata?,
    ) : ARScannerDataContribution
}
