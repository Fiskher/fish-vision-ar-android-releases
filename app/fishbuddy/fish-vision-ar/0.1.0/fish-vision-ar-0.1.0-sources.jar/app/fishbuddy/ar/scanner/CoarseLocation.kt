package app.fishbuddy.ar.scanner

/**
 * Location bucketed to roughly the nearest kilometre. The SDK never accepts raw GPS;
 * the consumer is responsible for the rounding step before constructing this type.
 *
 * @param latitude degrees, `-90.0..90.0`.
 * @param longitude degrees, `-180.0..180.0`.
 */
public data class CoarseLocation(
    public val latitude: Double,
    public val longitude: Double,
)
