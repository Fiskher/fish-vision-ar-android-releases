package app.fishbuddy.ar.scanner.internal.ml

import android.content.Context
import app.fishbuddy.ar.scanner.R

/** Loads species labels from `res/raw/labels.txt`. Memoised once per process. */
internal object Labels {

    @Volatile
    private var cached: List<String>? = null

    fun load(context: Context): List<String> {
        cached?.let { return it }
        val list = context.resources.openRawResource(R.raw.labels)
            .bufferedReader()
            .useLines { lines ->
                lines.map { it.trim() }.filter { it.isNotEmpty() }.toList()
            }
        cached = list
        return list
    }
}
