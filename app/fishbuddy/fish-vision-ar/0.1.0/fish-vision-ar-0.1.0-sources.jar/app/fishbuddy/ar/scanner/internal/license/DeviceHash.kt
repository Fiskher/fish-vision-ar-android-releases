package app.fishbuddy.ar.scanner.internal.license

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Stable per-install identifier. On first call, generates 16 random bytes,
 * SHA-256-hashes them, hex-encodes the digest, and persists to SharedPreferences.
 * Subsequent calls return the cached value.
 *
 * Survives app updates; wiped on uninstall — matches the "per-install"
 * semantics the backend's usage attribution expects.
 */
internal object DeviceHash {
    internal const val PREFS = "app.fishbuddy.ar.scanner.license"
    private const val KEY = "deviceHash"

    fun value(context: Context): String {
        val prefs = prefs(context)
        prefs.getString(KEY, null)?.takeIf { it.isNotEmpty() }?.let { return it }

        val bytes = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = MessageDigest.getInstance("SHA-256").digest(bytes)
            .joinToString("") { "%02x".format(it) }
        prefs.edit().putString(KEY, hash).apply()
        return hash
    }

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
