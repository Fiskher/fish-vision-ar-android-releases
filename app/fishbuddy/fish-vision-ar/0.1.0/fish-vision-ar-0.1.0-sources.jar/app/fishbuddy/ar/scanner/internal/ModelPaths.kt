package app.fishbuddy.ar.scanner.internal

import android.content.Context
import app.fishbuddy.ar.scanner.internal.ml.ModelSource
import java.io.File
import java.io.IOException

/** Centralised filesystem layout for downloaded TFLite models. */
internal object ModelPaths {

    private const val MODELS_SUBDIR = "fishvisionar/models/v1"
    internal const val CLASSIFICATION_FILE_NAME = "classification.tflite"
    internal const val SEGMENTATION_FILE_NAME = "segmentation.tflite"
    /** Path inside `assets/` that consumer apps can drop pre-bundled models into. */
    private const val ASSETS_MODELS_DIR = "fishvisionar/models/v1"

    internal fun modelsDir(context: Context): File =
        File(context.applicationContext.filesDir, MODELS_SUBDIR)

    /** Primary location — owned by the SDK downloader. */
    internal fun classificationFile(context: Context): File =
        File(modelsDir(context), CLASSIFICATION_FILE_NAME)

    /** Primary location — owned by the SDK downloader. */
    internal fun segmentationFile(context: Context): File =
        File(modelsDir(context), SEGMENTATION_FILE_NAME)

    /**
     * Dev-only fallback in external scoped storage (`Android/data/<pkg>/files/...`).
     *
     * The SDK *writes* only to internal storage. The fallback exists so engineers
     * can `adb push` model files for testing on devices where `run-as` is blocked
     * (Samsung + Android 16 routinely refuses `run-as` even for debuggable APKs).
     * If a model is present in either location it counts as "downloaded".
     */
    internal fun externalClassificationFile(context: Context): File? =
        context.applicationContext.getExternalFilesDir(null)
            ?.let { File(it, "$MODELS_SUBDIR/$CLASSIFICATION_FILE_NAME") }

    internal fun externalSegmentationFile(context: Context): File? =
        context.applicationContext.getExternalFilesDir(null)
            ?.let { File(it, "$MODELS_SUBDIR/$SEGMENTATION_FILE_NAME") }

    /** Heuristic: present + non-empty means "downloaded." A real SHA check is a TODO. */
    internal fun isPresent(file: File): Boolean = file.exists() && file.length() > 0

    /**
     * Whether the consumer app has bundled a model in its `assets/` directory.
     * Memory-mapping requires the asset to be uncompressed, which the library's
     * `noCompress(".tflite")` rule propagates via AAR merging — so the asset is
     * memory-mappable without any consumer-side configuration.
     */
    private fun assetIsPresent(context: Context, fileName: String): Boolean = try {
        context.applicationContext.assets.list(ASSETS_MODELS_DIR)
            ?.contains(fileName) == true
    } catch (_: IOException) {
        false
    }

    /**
     * First available copy of the classification model. Resolution order:
     *   1. Internal storage (where [ARScannerModelLoader.downloadIfNeeded] writes).
     *   2. External scoped storage (`/sdcard/Android/data/<pkg>/files/…` — dev push).
     *   3. Consumer app's `assets/fishvisionar/models/v1/…` (bundled delivery).
     * Returns `null` if no copy is reachable.
     */
    internal fun resolveClassificationFile(context: Context): ModelSource? =
        resolve(context, CLASSIFICATION_FILE_NAME, ::classificationFile, ::externalClassificationFile)

    internal fun resolveSegmentationFile(context: Context): ModelSource? =
        resolve(context, SEGMENTATION_FILE_NAME, ::segmentationFile, ::externalSegmentationFile)

    private inline fun resolve(
        context: Context,
        fileName: String,
        internalFile: (Context) -> File,
        externalFile: (Context) -> File?,
    ): ModelSource? {
        val primary = internalFile(context)
        if (isPresent(primary)) return ModelSource.FromFile(primary)
        val ext = externalFile(context)
        if (ext != null && isPresent(ext)) return ModelSource.FromFile(ext)
        if (assetIsPresent(context, fileName)) {
            return ModelSource.FromAsset(
                assetManager = context.applicationContext.assets,
                path = "$ASSETS_MODELS_DIR/$fileName",
            )
        }
        return null
    }
}
