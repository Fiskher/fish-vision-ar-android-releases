package app.fishbuddy.ar.scanner.internal.ar.rawdepth

import android.media.Image
import android.opengl.Matrix
import com.google.ar.core.CameraIntrinsics
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.ceil
import kotlin.math.sqrt

/**
 * Builds the full per-frame raw-depth point cloud that `DepthRenderer` draws as
 * the dense dotted texture across the visible scene. Distilled from
 * `DepthData.create()` in the Fishbuddy reference — only the scene-cloud-building
 * portion, no app/UI coupling.
 *
 * One FloatBuffer per call, layout: `[x, y, z, confidence] × N` in world coords.
 * Caller passes the result to [DepthRenderer.update]. Closing the input Images is
 * the caller's responsibility.
 */
internal object DepthScenePoints {

    /** Confidence cutoff: points below this normalised confidence are discarded. */
    private const val MIN_CONFIDENCE_NORMALIZED = 0.9f

    /** Distance sanity cap (m): points farther than this are discarded. */
    private const val MAX_DEPTH_METERS = 2.0f

    /** Target upper bound on rendered points; we subsample if the depth image is denser. */
    private const val MAX_POINTS_TO_RENDER = 20_000

    /**
     * @return a FloatBuffer with `[x, y, z, confidence]` per point in world coords,
     *   sized to fit at most [MAX_POINTS_TO_RENDER]. Position is rewound before
     *   return so the caller can pass it straight to GL.
     */
    fun build(
        depth: Image,
        confidence: Image,
        cameraTextureIntrinsics: CameraIntrinsics,
        modelMatrix: FloatArray,
    ): FloatBuffer {
        val depthPlane = depth.planes[0]
        // Endian-swap into a fresh buffer (Android Image planes come big-endian;
        // ShortBuffer needs little-endian for raw depth). Same trick the
        // reference DepthData uses.
        val rawDepth = depthPlane.buffer
        val depthBytes = java.nio.ByteBuffer.allocate(rawDepth.capacity()).order(ByteOrder.LITTLE_ENDIAN)
        rawDepth.rewind()
        while (rawDepth.hasRemaining()) depthBytes.put(rawDepth.get())
        depthBytes.rewind()
        val depthBuffer = depthBytes.asShortBuffer()

        val confidencePlane = confidence.planes[0]
        val confidenceBuffer = confidencePlane.buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)

        val intrinsicsDims = cameraTextureIntrinsics.imageDimensions
        val depthWidth = depth.width
        val depthHeight = depth.height
        val fx = cameraTextureIntrinsics.focalLength[0] * depthWidth / intrinsicsDims[0]
        val fy = cameraTextureIntrinsics.focalLength[1] * depthHeight / intrinsicsDims[1]
        val cx = cameraTextureIntrinsics.principalPoint[0] * depthWidth / intrinsicsDims[0]
        val cy = cameraTextureIntrinsics.principalPoint[1] * depthHeight / intrinsicsDims[1]

        // Subsample stride so we don't exceed MAX_POINTS_TO_RENDER on dense images.
        val totalPixels = depthWidth * depthHeight
        val step = ceil(sqrt(totalPixels.toDouble() / MAX_POINTS_TO_RENDER)).toInt().coerceAtLeast(1)

        val points = FloatBuffer.allocate(
            (depthWidth / step) * (depthHeight / step) * DepthConstants.FLOATS_PER_POINT,
        )
        val pointCamera = FloatArray(4)
        val pointWorld = FloatArray(4)

        var y = 0
        while (y < depthHeight) {
            var x = 0
            while (x < depthWidth) {
                val depthMillimeters = depthBuffer[y * depthWidth + x].toInt()
                if (depthMillimeters == 0) { x += step; continue }
                val depthMeters = depthMillimeters / 1000.0f
                if (depthMeters > MAX_DEPTH_METERS) { x += step; continue }

                val conf = confidenceBuffer[
                    y * confidencePlane.rowStride + x * confidencePlane.pixelStride,
                ].toInt() and 0xFF
                val confidenceNormalized = conf / 255.0f
                if (confidenceNormalized < MIN_CONFIDENCE_NORMALIZED) { x += step; continue }

                pointCamera[0] = depthMeters * (x - cx) / fx
                pointCamera[1] = depthMeters * (cy - y) / fy
                pointCamera[2] = -depthMeters
                pointCamera[3] = 1f

                Matrix.multiplyMV(pointWorld, 0, modelMatrix, 0, pointCamera, 0)
                points.put(pointWorld[0])
                points.put(pointWorld[1])
                points.put(pointWorld[2])
                points.put(confidenceNormalized)
                x += step
            }
            y += step
        }
        points.flip()
        return points
    }
}
