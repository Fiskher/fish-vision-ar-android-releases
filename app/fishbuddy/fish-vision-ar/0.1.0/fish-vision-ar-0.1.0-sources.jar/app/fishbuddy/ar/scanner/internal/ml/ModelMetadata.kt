package app.fishbuddy.ar.scanner.internal.ml

import android.util.Log
import org.tensorflow.lite.support.metadata.MetadataExtractor
import org.tensorflow.lite.support.metadata.schema.NormalizationOptions
import org.tensorflow.lite.support.metadata.schema.ProcessUnitOptions
import java.nio.ByteBuffer

/**
 * Reads model-metadata normalization params from a `.tflite` file's embedded
 * metadata table. The Fishbuddy reference uses Android's `mlModelBinding`
 * code-gen, which silently applies these normalizations before inference; our
 * raw `Interpreter` path doesn't, so without this step the model sees
 * `[0, 255]` floats when it expects `[-1, 1]` (or similar), and inference
 * quality collapses — classifier misidentifies species, segmenter masks come
 * out empty or full-frame, etc.
 *
 * Returns `(mean, std)` if a NormalizationOptions block is found on input
 * tensor 0, or `null` if the model has no metadata or the metadata block has
 * no normalization unit. Callers should pass the resulting arrays straight to
 * `NormalizeOp(mean, std)` in their `ImageProcessor` chain.
 */
internal object ModelMetadata {

    private const val TAG = "ModelMetadata"

    data class Normalization(val mean: FloatArray, val std: FloatArray) {
        override fun toString(): String = "Normalization(mean=${mean.toList()}, std=${std.toList()})"
    }

    fun readNormalization(modelBuffer: ByteBuffer, debugName: String): Normalization? {
        val result = runCatching {
            val extractor = MetadataExtractor(modelBuffer)
            if (!extractor.hasMetadata()) {
                Log.d(TAG, "$debugName has no embedded metadata")
                return@runCatching null
            }
            val inputMetadata = extractor.getInputTensorMetadata(0) ?: run {
                Log.d(TAG, "$debugName has no input tensor metadata")
                return@runCatching null
            }
            val count = inputMetadata.processUnitsLength()
            for (i in 0 until count) {
                val unit = inputMetadata.processUnits(i) ?: continue
                if (unit.optionsType() != ProcessUnitOptions.NormalizationOptions) continue
                val opts = unit.options(NormalizationOptions()) as NormalizationOptions
                val mean = FloatArray(opts.meanLength()) { opts.mean(it) }
                val std = FloatArray(opts.stdLength()) { opts.std(it) }
                return@runCatching Normalization(mean, std)
            }
            Log.d(TAG, "$debugName has metadata but no NormalizationOptions unit")
            null
        }.onFailure {
            Log.w(TAG, "$debugName metadata read failed: ${it.message}")
        }.getOrNull()
        if (result != null) Log.d(TAG, "$debugName normalization=$result")
        return result
    }
}
