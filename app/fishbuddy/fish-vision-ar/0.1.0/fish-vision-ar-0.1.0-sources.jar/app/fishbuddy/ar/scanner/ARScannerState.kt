package app.fishbuddy.ar.scanner

/** Lifecycle of an [ARScannerController]. Drives UI affordances. */
public sealed interface ARScannerState {
    /** No active session. */
    public data object Idle : ARScannerState

    /** ARCore session is starting up. */
    public data object Initializing : ARScannerState

    /** Ready to scan; AR tracking is stable. */
    public data object Ready : ARScannerState

    /** A scan is in flight. */
    public data object Scanning : ARScannerState

    /** Terminal failure; call [ARScannerController.reset] to recover. */
    public data class Failed(public val error: ARScannerError) : ARScannerState
}
