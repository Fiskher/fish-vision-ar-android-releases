package app.fishbuddy.ar.scanner.internal.ml

import android.graphics.Bitmap
import android.graphics.Matrix
import android.util.Log
import app.fishbuddy.ar.scanner.internal.ScanFlags
import app.fishbuddy.ar.scanner.internal.diagnostics.ScanValidationLogger
import app.fishbuddy.ar.scanner.ARClassification
import app.fishbuddy.ar.scanner.ARScanOutcome
import app.fishbuddy.ar.scanner.ARScannerError
import com.google.ar.core.Config
import com.google.ar.core.Frame
import com.google.ar.core.exceptions.NotYetAvailableException

/**
 * One-shot "scan a fish without placing anchors" pipeline.
 *
 * Runs entirely on the calling thread (the GL thread in practice — blocks rendering
 * for ~1–2 s, which freezes the camera view at the captured frame; matches Fishbuddy's
 * existing UX).
 *
 * Pipeline:
 *  1. Acquire camera image, convert YUV → Bitmap, crop to 3:4.
 *  2. Run classifier for the species label.
 *  3. Run segmenter for the fish mask.
 *  4. Detect head/tail endpoints in the mask.
 *  5. Acquire raw depth + confidence images, unproject the two endpoints to 3-D,
 *     compute distance.
 *  6. Return an [ARScanOutcome] with `measurementMeters` populated when depth is
 *     valid, or `null` when the depth lookup failed.
 */
internal class AutoMeasurePipeline(
    private val classifier: ImageClassifier,
    private val segmenter: Segmenter,
) {

    /**
     * @param orientationDegrees sensor-to-display rotation (typically 90 on a
     *   portrait-held phone, 0 on landscape). The cropped bitmap is rotated
     *   by this much before classification so the model sees the fish upright;
     *   segmentation + endpoint detection stay on the unrotated bitmap so the
     *   endpoint coords still align with the depth-image transform.
     * @return null if depth isn't supported on this device — caller should fall back.
     */
    fun run(
        frame: Frame,
        depthMode: Config.DepthMode,
        scoreThreshold: Float,
        orientationDegrees: Int,
        armedOut: ((ArmedScan) -> Unit)? = null,
    ): ARScanOutcome? {
        // === Step 1: acquire ALL Frame-dependent data BEFORE running ML ===
        //
        // ML inference takes ~2 seconds. If we hold off on acquiring the raw
        // depth image until *after* inference, ARCore considers the Frame stale
        // and acquireRawDepthImage16Bits() throws NotYetAvailable. Acquiring
        // upfront mirrors what Fishbuddy's DepthData.create() does and lets us
        // close the Images later without affecting measurement.
        val cameraImage = try {
            frame.acquireCameraImage()
        } catch (e: NotYetAvailableException) {
            Log.w(TAG, "Camera image not ready", e)
            return null
        }
        val sourceBitmap = try {
            YuvToBitmap.convert(cameraImage)
        } finally {
            cameraImage.close()
        }

        // Snapshot the per-frame transform inputs *now* — the Frame object
        // becomes unreliable once ML takes over the GL thread for seconds.
        val modelMatrix = FloatArray(16).also { frame.camera.pose.toMatrix(it, 0) }
        val cameraIntrinsics = frame.camera.textureIntrinsics

        val depthImage = if (depthMode != Config.DepthMode.DISABLED) {
            runCatching { frame.acquireRawDepthImage16Bits() }
                .onFailure { Log.d(TAG, "Raw depth acquire failed upfront: ${it.message}") }
                .getOrNull()
        } else null
        val confidenceImage = if (depthImage != null) {
            runCatching { frame.acquireRawDepthConfidenceImage() }
                .onFailure {
                    Log.d(TAG, "Confidence acquire failed: ${it.message}")
                    depthImage.close()
                }
                .getOrNull()
        } else null
        // From this point we own depthImage + confidenceImage and must close
        // both before returning. Holding them across ML inference is safe.

        return try {
            buildOutcome(
                frame = frame,
                sourceBitmap = sourceBitmap,
                depthImage = depthImage,
                confidenceImage = confidenceImage,
                modelMatrix = modelMatrix,
                cameraIntrinsics = cameraIntrinsics,
                depthMode = depthMode,
                scoreThreshold = scoreThreshold,
                orientationDegrees = orientationDegrees,
                armedOut = armedOut,
            )
        } finally {
            depthImage?.close()
            confidenceImage?.close()
        }
    }

    private fun buildOutcome(
        frame: Frame,
        sourceBitmap: android.graphics.Bitmap,
        depthImage: android.media.Image?,
        confidenceImage: android.media.Image?,
        modelMatrix: FloatArray,
        cameraIntrinsics: com.google.ar.core.CameraIntrinsics,
        depthMode: Config.DepthMode,
        scoreThreshold: Float,
        orientationDegrees: Int,
        armedOut: ((ArmedScan) -> Unit)? = null,
    ): ARScanOutcome {
        val (croppedBitmap, cropInfo) = ImageCrop.cropToPortrait3x4(sourceBitmap)
        Log.d(
            TAG,
            "source=${sourceBitmap.width}x${sourceBitmap.height} -> " +
                "cropped=${croppedBitmap.width}x${croppedBitmap.height} crop=$cropInfo " +
                "orientation=${orientationDegrees}°  depth=${depthImage != null}",
        )

        // === Step 2: ML inference (~2 seconds) ===
        val classifierInput = rotateIfNeeded(croppedBitmap, orientationDegrees)
        val allClassifications = classifier.classify(classifierInput)
        val mask = segmenter.segment(croppedBitmap)
        val (maskW, maskH) = segmenter.inputWidth to segmenter.inputHeight
        val fishMask = extractForegroundChannel(mask, segmenter.outputShape, maskW, maskH)
        val maskFishPixels = fishMask.count { it > 0.5f }
        val maskMin = fishMask.min()
        val maskMax = fishMask.max()
        val maskMean = fishMask.average()
        Log.d(
            TAG,
            "mask: ${maskW}x$maskH  fishPixels=$maskFishPixels  " +
                "range=[${"%.3f".format(maskMin)}..${"%.3f".format(maskMax)}]  " +
                "mean=${"%.3f".format(maskMean)}  classifications=${allClassifications.size} " +
                "top=${allClassifications.firstOrNull()?.label}@${allClassifications.firstOrNull()?.confidence}",
        )

        val endpoints = FishEndpointDetector.detect(
            mask = fishMask,
            maskWidth = maskW,
            maskHeight = maskH,
            cropInfo = cropInfo,
        )
        Log.d(TAG, "endpoints=$endpoints  depthMode=$depthMode")

        // === Step 3: depth measurement using already-held images ===
        val depthResult = if (endpoints != null && depthImage != null && confidenceImage != null) {
            runCatching {
                val raw = DepthMeasurer.measureMeters(
                    frame = frame,
                    depthImage = depthImage,
                    confidenceImage = confidenceImage,
                    modelMatrix = modelMatrix,
                    cameraIntrinsics = cameraIntrinsics,
                    cpuPoint1 = endpoints.first,
                    cpuPoint2 = endpoints.second,
                )
                val meters = raw.meters
                if (meters != null && meters > MAX_PLAUSIBLE_LENGTH_METERS) {
                    raw.copy(meters = null, rejectReason = "over_max_plausible_length")
                } else {
                    raw
                }
            }.onFailure { Log.w(TAG, "depth measurement threw", it) }.getOrNull()
        } else {
            Log.d(
                TAG,
                "skipping depth measurement (endpoints=$endpoints, depthImage=${depthImage != null})",
            )
            null
        }
        val measurement = depthResult?.meters
        Log.d(TAG, "depth measurement = $measurement m")

        val top = allClassifications.firstOrNull()
            ?: ARClassification(label = "unknown", confidence = 0.0)

        // Phase-0 validation harness. No-op unless ScanValidationLogger.enabled
        // was set by a debug build; observes only, never alters `measurement`.
        if (endpoints != null && depthResult != null) {
            ScanValidationLogger.logMeasurement(
                path = ScanValidationLogger.PATH_DEPTH,
                lengthCm = depthResult.meters?.times(CM_PER_METRE),
                p1x = endpoints.first.x, p1y = endpoints.first.y,
                p2x = endpoints.second.x, p2y = endpoints.second.y,
                d1x = depthResult.depthPx1.first, d1y = depthResult.depthPx1.second,
                d2x = depthResult.depthPx2.first, d2y = depthResult.depthPx2.second,
                depth1mm = depthResult.depth1mm, conf1 = depthResult.conf1,
                depth2mm = depthResult.depth2mm, conf2 = depthResult.conf2,
                rejectReason = depthResult.rejectReason,
                fishPixelFraction = maskFishPixels.toFloat() / (maskW * maskH).toFloat(),
                speciesTop1 = top.label,
                speciesScore = top.confidence,
            )
        }
        val aboveThreshold = allClassifications.filter { it.confidence >= scoreThreshold }

        // D6. Hand the caller everything needed to keep sampling this same fish on
        // later frames: the endpoints are fixed here and never recomputed, so the
        // follow-up frames cost a depth lookup rather than another ML pass.
        if (armedOut != null && endpoints != null) {
            armedOut(
                ArmedScan(
                    croppedBitmap = croppedBitmap,
                    topClassification = top,
                    allClassifications = aboveThreshold,
                    endpoints = endpoints,
                    samples = mutableListOf<Double>().apply { measurement?.let { add(it) } },
                ),
            )
        }

        return ARScanOutcome(
            image = croppedBitmap,
            topClassification = top,
            allClassifications = aboveThreshold,
            measurementMeters = measurement,
        )
    }

    /**
     * A scan whose endpoints have been fixed, still collecting depth samples.
     *
     * Driven from the GL thread one frame at a time, so it is deliberately not
     * thread-safe.
     */
    internal class ArmedScan(
        val croppedBitmap: Bitmap,
        val topClassification: ARClassification,
        val allClassifications: List<ARClassification>,
        val endpoints: Pair<MaskPoint, MaskPoint>,
        val samples: MutableList<Double>,
    ) {
        var framesSeen: Int = 0
            private set

        /** True once the sample target or the frame budget has been reached. */
        val isComplete: Boolean
            get() = samples.size >= ScanFlags.TEMPORAL_TARGET_SAMPLES ||
                framesSeen >= ScanFlags.TEMPORAL_FRAME_BUDGET

        fun recordFrame() { framesSeen++ }
    }

    /**
     * Re-measure the armed scan's fixed endpoints against a newer [frame],
     * unprojecting with that frame's own pose. Cheap: a depth lookup, no ML.
     *
     * Failures are silent by design — a frame that can't produce depth just
     * doesn't contribute a sample, and the frame budget bounds how long that can
     * go on.
     */
    fun sampleAgain(armed: ArmedScan, frame: Frame, depthMode: Config.DepthMode) {
        armed.recordFrame()
        if (depthMode == Config.DepthMode.DISABLED) return
        runCatching {
            val modelMatrix = FloatArray(16).also { frame.camera.pose.toMatrix(it, 0) }
            val depthImage = frame.acquireRawDepthImage16Bits() ?: return
            depthImage.use { depth ->
                val confidence = frame.acquireRawDepthConfidenceImage() ?: return
                confidence.use { conf ->
                    val result = DepthMeasurer.measureMeters(
                        frame = frame,
                        depthImage = depth,
                        confidenceImage = conf,
                        modelMatrix = modelMatrix,
                        cameraIntrinsics = frame.camera.textureIntrinsics,
                        cpuPoint1 = armed.endpoints.first,
                        cpuPoint2 = armed.endpoints.second,
                    )
                    val meters = result.meters
                    if (meters != null && meters <= MAX_PLAUSIBLE_LENGTH_METERS) {
                        armed.samples += meters
                    }
                }
            }
        }.onFailure { Log.d(TAG, "aggregation sample skipped: ${it.message}") }
    }

    /**
     * Collapse the collected samples into one outcome: median length plus a
     * one-sigma band, outliers rejected by MAD.
     *
     * With no usable samples the measurement is null — the same answer the
     * single-frame path gives when depth fails, rather than a fabricated number.
     */
    fun finish(armed: ArmedScan): ARScanOutcome {
        val aggregate = TemporalAggregator.aggregate(armed.samples)
        Log.d(
            TAG,
            "aggregated ${armed.samples.size} sample(s) over ${armed.framesSeen} frame(s) -> " +
                "median=${aggregate?.median} sigma=${aggregate?.sigma}",
        )
        if (aggregate != null) {
            ScanValidationLogger.logTemporal(
                lengthCm = aggregate.median * CM_PER_METRE,
                uncertaintyCm = aggregate.sigma * CM_PER_METRE,
                rawSamples = aggregate.total,
                keptSamples = aggregate.kept,
                speciesTop1 = armed.topClassification.label,
                speciesScore = armed.topClassification.confidence,
            )
        }
        return ARScanOutcome(
            image = armed.croppedBitmap,
            topClassification = armed.topClassification,
            allClassifications = armed.allClassifications,
            measurementMeters = aggregate?.median,
            // A lone sample carries no spread; report null rather than a
            // sigma of 0, which would read as a precise measurement.
            measurementUncertaintyMeters = aggregate?.sigma?.takeIf { aggregate.kept > 1 },
            measurementSampleCount = aggregate?.kept ?: 0,
        )
    }

    private fun rotateIfNeeded(bitmap: Bitmap, degrees: Int): Bitmap {
        if (degrees == 0) return bitmap
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    companion object {
        const val MAX_PLAUSIBLE_LENGTH_METERS = 2.0
        private const val CM_PER_METRE = 100.0
        private const val TAG = "AutoMeasurePipeline"
    }
}

/**
 * Pulls the foreground channel out of a segmentation output tensor.
 *
 * - `[1, H, W]` or `[H, W]`: already a single-channel probability map; return as-is.
 * - `[1, H, W, 1]`: same idea, four-axis form; return as-is.
 * - `[1, H, W, C]` with C ≥ 2: pick the channel whose high-confidence region is
 *   most spatially **localized** (smallest bounding box relative to the image).
 *   For binary fish segmentation, the "fish" channel is small (the fish itself)
 *   and the "background" channel covers most of the image — picking the more
 *   localized channel gets us the fish regardless of which index the model
 *   chose for foreground. Avoids the channel-inversion bug that would otherwise
 *   silently land endpoints on the floor instead of the fish.
 *
 * Top-level so it's reachable from `src/test`; the underlying logic is stateless.
 */
internal fun extractForegroundChannel(
    mask: FloatArray,
    shape: IntArray,
    w: Int,
    h: Int,
): FloatArray {
    val channels = when (shape.size) {
        3 -> 1
        4 -> shape[3]
        else -> return mask
    }
    if (channels <= 1) return mask

    val perChannel = Array(channels) { ch -> extractChannel(mask, w, h, ch, channels) }
    val scores = FloatArray(channels) { ch -> localizationScore(perChannel[ch], w, h) }
    val bestChannel = scores.indices.maxByOrNull { scores[it] } ?: (channels - 1)
    android.util.Log.d(
        "ExtractFgChannel",
        "channels=$channels scores=${scores.toList()} picked=$bestChannel",
    )
    return perChannel[bestChannel]
}

/** Repack interleaved `[H, W, C]` floats into a flat `[H*W]` array for one channel. */
private fun extractChannel(
    mask: FloatArray,
    w: Int,
    h: Int,
    channel: Int,
    channels: Int,
): FloatArray {
    val out = FloatArray(w * h)
    var src = channel
    var dst = 0
    while (dst < out.size) {
        out[dst++] = mask[src]
        src += channels
    }
    return out
}

/**
 * Higher = more localized. A region whose bounding box covers the whole image
 * scores ~0; a region confined to a small fraction of the image scores ~1.
 * Returns 0 when no pixel exceeds the threshold.
 */
private fun localizationScore(
    mask: FloatArray,
    w: Int,
    h: Int,
    threshold: Float = 0.5f,
): Float {
    var minX = w; var maxX = -1
    var minY = h; var maxY = -1
    var count = 0
    var i = 0
    for (y in 0 until h) {
        for (x in 0 until w) {
            if (mask[i] > threshold) {
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
                count++
            }
            i++
        }
    }
    if (count == 0) return 0f
    val bbArea = (maxX - minX + 1).toLong() * (maxY - minY + 1).toLong()
    val imageArea = w.toLong() * h.toLong()
    return 1f - (bbArea.toFloat() / imageArea.toFloat())
}
