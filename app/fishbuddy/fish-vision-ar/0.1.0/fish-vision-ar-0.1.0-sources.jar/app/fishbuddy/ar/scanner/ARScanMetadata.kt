package app.fishbuddy.ar.scanner

/**
 * Optional metadata attached to a telemetry-uploaded scan. Every field is nullable;
 * provide what the customer is willing to share.
 *
 * @param hashedUserId opaque hash of the customer's internal user id. Drives MAU
 *   billing on the backend; the SDK never sees a raw user id.
 * @param coarseLocation location bucketed to roughly the nearest kilometre. Never
 *   raw GPS.
 * @param weather snapshot of weather at the scan time/place.
 * @param waterTemperatureCelsius optional water temperature reading.
 * @param userConfirmedSpecies the species the user told the app this catch was,
 *   if any. Used as a training-set label.
 * @param custom additional key/value pairs the customer wants to ship along.
 */
public data class ARScanMetadata(
    public val hashedUserId: String? = null,
    public val coarseLocation: CoarseLocation? = null,
    public val weather: WeatherSnapshot? = null,
    public val waterTemperatureCelsius: Double? = null,
    public val userConfirmedSpecies: String? = null,
    public val custom: Map<String, String> = emptyMap(),
)
