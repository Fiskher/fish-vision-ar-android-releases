package app.fishbuddy.ar.scanner.internal.ml

import android.graphics.Bitmap
import kotlin.math.abs

/**
 * Geometry of how a cropped bitmap relates to its source. Lets endpoint coordinates
 * detected in the cropped image be mapped back into the source-image frame.
 */
internal data class CropInfo(
    val left: Int,
    val top: Int,
    val width: Int,
    val height: Int,
    val srcWidth: Int,
    val srcHeight: Int,
)

internal object ImageCrop {

    /**
     * Centre-crop to the 4:3 family. If the bitmap is already 4:3 or 3:4 (within
     * [eps]) it is returned unchanged with the identity [CropInfo]. Otherwise the
     * longer dimension is trimmed.
     *
     * Port of `BitmapUtils.cropToPortrait3x4WithInfo` with no app coupling.
     */
    fun cropToPortrait3x4(bitmap: Bitmap, eps: Float = 1e-3f): Pair<Bitmap, CropInfo> {
        val srcW = bitmap.width
        val srcH = bitmap.height
        val r = srcW.toFloat() / srcH.toFloat()
        val target = 4f / 3f
        val near4by3 = abs(r - target) / maxOf(r, target) < eps
        val near3by4 = abs(r - (1f / target)) / maxOf(r, 1f / target) < eps
        if (near4by3 || near3by4) {
            return bitmap to CropInfo(0, 0, srcW, srcH, srcW, srcH)
        }
        val desiredAspect = if (r >= 1f) target else 1f / target

        val cropW: Int
        val cropH: Int
        val left: Int
        val top: Int
        if (r > desiredAspect) {
            cropH = srcH
            cropW = (cropH * desiredAspect).toInt()
            left = (srcW - cropW) / 2
            top = 0
        } else {
            cropW = srcW
            cropH = (cropW / desiredAspect).toInt()
            left = 0
            top = (srcH - cropH) / 2
        }
        val cropped = Bitmap.createBitmap(bitmap, left, top, cropW, cropH)
        return cropped to CropInfo(left, top, cropW, cropH, srcW, srcH)
    }
}
